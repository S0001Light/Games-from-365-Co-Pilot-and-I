DIVING PENGUIN WORD GUESS - JSON DICTIONARY EDITION

Run:
  python diving_penguin_dictionary_game.py

AUTOMATIC DICTIONARY FILES
Place files beside the Python program. At startup it checks:
  dictionary_A
  dictionary_A.json
  dictionary_B
  dictionary_B.json
  dictionary_*.json

You can also click Open Dictionary and select one or more JSON files.

SUPPORTED JSON SHAPES
1. Flat word mapping:
   {"apple": "A round fruit", "boat": "A vessel"}

2. Definition objects:
   {"apple": {"definition": "A round fruit"}}

3. Entry arrays:
   [{"word": "apple", "definition": "A round fruit"}]

4. Letter groups:
   {"A": {"apple": "A round fruit"}, "B": {"boat": "A vessel"}}

The game keeps alphabetic words containing 3 through 12 letters. The definition
is displayed as the clue. If no dictionary files are found, the starter words
remain available.

RULES
Each wrong letter guess moves the penguin up one step. Guess the word before the
penguin reaches the water and dives.
