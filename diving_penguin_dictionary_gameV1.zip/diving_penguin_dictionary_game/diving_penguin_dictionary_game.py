import json
import random
import re
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

WORDS = [
    ("OCEAN", "A huge body of salt water"), ("FROST", "Thin ice crystals"),
    ("WHALE", "A very large sea mammal"), ("SHELL", "A hard covering found at the beach"),
    ("WATER", "Penguins swim through it"), ("SQUID", "A sea animal with tentacles"),
    ("GLIDE", "To move smoothly"), ("STONE", "A small rock"),
    ("WAVES", "They roll across the sea"), ("SNOW", "Frozen flakes from the sky"),
    ("FISH", "A common penguin meal"), ("DIVE", "To go beneath the water"),
    ("ICE", "Frozen water"), ("COLD", "The opposite of hot"),
    ("BEACH", "Land beside the water"), ("FLIPPER", "A penguin uses these to swim"),
]

BG = "#071726"
SKY = "#8bd7f6"
ICE = "#eafaff"
WATER = "#087fb5"
WATER2 = "#075985"
STEP = "#d9f5ff"
STEP_EDGE = "#7dd3fc"
YELLOW = "#facc15"
RED = "#ef4444"
GREEN = "#22c55e"
WHITE = "#ffffff"

def clean_definition(value):
    """Extract readable definition text from common dictionary JSON values."""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts = [clean_definition(item) for item in value]
        return "; ".join(part for part in parts if part)
    if isinstance(value, dict):
        for key in ("definition", "definitions", "meaning", "meanings", "description", "def", "gloss"):
            if key in value:
                text = clean_definition(value[key])
                if text:
                    return text
        parts = [clean_definition(item) for item in value.values()]
        return "; ".join(part for part in parts if part)
    return ""


def add_dictionary_entry(output, word, definition):
    word = re.sub(r"[^A-Za-z]", "", str(word)).upper()
    definition = clean_definition(definition)
    if 3 <= len(word) <= 12 and definition:
        output[word] = definition[:500]


def parse_dictionary_json(data):
    """Support flat objects, nested letter objects, and word-entry arrays."""
    output = {}
    if isinstance(data, list):
        for entry in data:
            if isinstance(entry, dict):
                word = entry.get("word") or entry.get("term") or entry.get("headword")
                if word:
                    add_dictionary_entry(output, word, entry)
    elif isinstance(data, dict):
        # Single entry object.
        direct_word = data.get("word") or data.get("term") or data.get("headword")
        if direct_word:
            add_dictionary_entry(output, direct_word, data)
        for key, value in data.items():
            # Letter groups such as {"A": {"apple": "..."}}.
            if len(str(key)) == 1 and isinstance(value, dict):
                for nested_word, nested_value in value.items():
                    add_dictionary_entry(output, nested_word, nested_value)
            else:
                add_dictionary_entry(output, key, value)
    return output


class Game:
    def __init__(self, root):
        self.root = root
        root.title("Diving Penguin Word Guess")
        root.geometry("1000x760")
        root.minsize(760, 600)
        root.configure(bg=BG)
        root.rowconfigure(1, weight=1)
        root.columnconfigure(0, weight=1)

        self.dictionary = {}
        self.dictionary_files = []
        self.score = 0
        self.round = 0
        self.word = ""
        self.hint = ""
        self.guessed = set()
        self.wrong = []
        self.max_steps = 7
        self.step = 0
        self.status = tk.StringVar()
        self.word_display = tk.StringVar()
        self.score_display = tk.StringVar()
        self.hint_display = tk.StringVar()
        self.dictionary_display = tk.StringVar()

        top = tk.Frame(root, bg="#0d2940", padx=12, pady=9)
        top.grid(row=0, column=0, sticky="ew")
        top.columnconfigure(4, weight=1)
        tk.Label(top, text="DIVING PENGUIN WORD GUESS", bg="#0d2940", fg=WHITE,
                 font=("Segoe UI", 18, "bold")).grid(row=0, column=0, padx=(0,18))
        tk.Label(top, textvariable=self.score_display, bg="#0d2940", fg=YELLOW,
                 font=("Consolas", 13, "bold")).grid(row=0, column=1, padx=8)
        tk.Button(top, text="New Word", command=self.new_word).grid(row=0, column=2, padx=5)
        tk.Button(top, text="New Game", command=self.new_game).grid(row=0, column=3, padx=5)
        tk.Button(top, text="Open Dictionary", command=self.open_dictionary).grid(row=0, column=4, padx=5)
        tk.Label(top, textvariable=self.dictionary_display, bg="#0d2940", fg="#bae6fd",
                 font=("Segoe UI", 9)).grid(row=0, column=5, sticky="e", padx=8)

        body = tk.Frame(root, bg=BG)
        body.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)

        self.canvas = tk.Canvas(body, bg=SKY, highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky="nsew", padx=(0,8))
        self.canvas.bind("<Configure>", lambda e:self.draw())

        side = tk.Frame(body, bg="#0d2940", padx=14, pady=14)
        side.grid(row=0, column=1, sticky="nsew")
        side.columnconfigure(0, weight=1)
        tk.Label(side, text="GUESS THE WORD", bg="#0d2940", fg=WHITE,
                 font=("Segoe UI", 15, "bold")).grid(row=0,column=0,sticky="w")
        tk.Label(side, textvariable=self.word_display, bg="#071726", fg=YELLOW,
                 font=("Consolas", 23, "bold"), padx=10, pady=14).grid(row=1,column=0,sticky="ew",pady=(8,10))
        tk.Label(side, textvariable=self.hint_display, bg="#0d2940", fg="#bae6fd",
                 font=("Segoe UI", 11), wraplength=310, justify="left").grid(row=2,column=0,sticky="ew",pady=(0,12))

        letters = tk.Frame(side, bg="#0d2940")
        letters.grid(row=3,column=0,sticky="ew")
        self.buttons = {}
        for i,ch in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
            r,c=divmod(i,7)
            b=tk.Button(letters,text=ch,width=3,font=("Segoe UI",10,"bold"),command=lambda x=ch:self.guess(x))
            b.grid(row=r,column=c,padx=2,pady=2,sticky="ew")
            self.buttons[ch]=b
        for c in range(7): letters.columnconfigure(c,weight=1)

        tk.Label(side,textvariable=self.status,bg="#071726",fg=WHITE,wraplength=310,
                 justify="left",anchor="nw",padx=10,pady=10).grid(row=4,column=0,sticky="ew",pady=12)
        tk.Label(side,text="Each wrong letter guess moves the penguin UP one ice step.\nReach the top and the penguin dives into the water.\nGuess the word before that happens!",
                 bg="#0d2940",fg="#cbd5e1",justify="left",wraplength=315).grid(row=5,column=0,sticky="ew")

        root.bind("<Key>", self.key)
        self.auto_load_dictionaries()
        self.new_game()

    def dictionary_candidates(self):
        base = Path(__file__).resolve().parent
        names = ["dictionary_A", "dictionary_A.json", "dictionary_B", "dictionary_B.json"]
        candidates = [base / name for name in names]
        candidates.extend(sorted(base.glob("dictionary_*.json")))
        unique = []
        for path in candidates:
            if path.is_file() and path not in unique:
                unique.append(path)
        return unique

    def auto_load_dictionaries(self):
        paths = self.dictionary_candidates()
        if paths:
            self.load_dictionary_files(paths, announce=False)
        else:
            self.dictionary_display.set("Built-in words")

    def open_dictionary(self):
        paths = filedialog.askopenfilenames(
            title="Open dictionary JSON files",
            filetypes=(("JSON dictionaries", "*.json"), ("All files", "*.*")),
        )
        if paths:
            self.load_dictionary_files([Path(path) for path in paths], announce=True)
            self.new_word()

    def load_dictionary_files(self, paths, announce=True):
        loaded = 0
        added = 0
        errors = []
        for path in paths:
            try:
                with path.open("r", encoding="utf-8-sig") as handle:
                    data = json.load(handle)
                entries = parse_dictionary_json(data)
                before = len(self.dictionary)
                self.dictionary.update(entries)
                added += len(self.dictionary) - before
                loaded += 1
                if str(path) not in self.dictionary_files:
                    self.dictionary_files.append(str(path))
            except Exception as error:
                errors.append(f"{path.name}: {error}")
        if loaded:
            self.dictionary_display.set(f"Dictionary: {len(self.dictionary):,} words / {loaded} file(s)")
        elif not self.dictionary:
            self.dictionary_display.set("Built-in words")
        if announce:
            if loaded:
                messagebox.showinfo("Dictionary loaded", f"Loaded {loaded} file(s).\nAdded {added:,} new playable words.\nTotal: {len(self.dictionary):,}")
            if errors:
                messagebox.showwarning("Dictionary errors", "\n".join(errors[:8]))

    def choose_word(self):
        if self.dictionary:
            word = random.choice(tuple(self.dictionary))
            return word, self.dictionary[word]
        return random.choice(WORDS)

    def new_game(self):
        self.score=0; self.round=0
        self.new_word()

    def new_word(self):
        self.word,self.hint=self.choose_word()
        self.guessed=set(); self.wrong=[]; self.step=0; self.round+=1
        for b in self.buttons.values(): b.config(state="normal",bg="SystemButtonFace")
        self.status.set("Pick a letter. One wrong guess = one step upward.")
        self.refresh(); self.draw()

    def key(self,e):
        ch=e.char.upper()
        if ch in self.buttons: self.guess(ch)

    def guess(self,ch):
        if ch in self.guessed or ch in self.wrong:return
        self.buttons[ch].config(state="disabled")
        if ch in self.word:
            self.guessed.add(ch); self.buttons[ch].config(bg="#86efac")
            self.score += 10*self.word.count(ch)
            self.status.set(f"{ch} is in the word. The penguin stays put.")
        else:
            self.wrong.append(ch); self.step += 1; self.buttons[ch].config(bg="#fca5a5")
            self.status.set(f"{ch} is not in the word. Penguin climbs one step!")
        self.refresh(); self.draw()
        if all(c in self.guessed for c in self.word):
            self.score += max(20,100-self.step*10); self.refresh()
            messagebox.showinfo("You got it!",f"The word was {self.word}.\nThe penguin is safe!")
            self.root.after(150,self.new_word)
        elif self.step >= self.max_steps:
            self.draw(diving=True)
            messagebox.showinfo("Splash!",f"The penguin reached the top and dove in!\nThe word was {self.word}.")
            self.root.after(150,self.new_word)

    def refresh(self):
        shown=" ".join(c if c in self.guessed else "_" for c in self.word)
        self.word_display.set(shown)
        self.hint_display.set("Definition: "+self.hint)
        self.score_display.set(f"SCORE {self.score:05d}   ROUND {self.round}")

    def draw_penguin(self,x,y,s,diving=False):
        c=self.canvas
        if diving:
            c.create_oval(x-22*s,y-10*s,x+22*s,y+10*s,fill="#dbeafe",outline="")
            c.create_oval(x-12*s,y-23*s,x+12*s,y+18*s,fill="#111827",outline=WHITE,width=2)
            c.create_oval(x-7*s,y-15*s,x+7*s,y+13*s,fill=WHITE,outline="")
            c.create_polygon(x+10*s,y-5*s,x+25*s,y,x+10*s,y+5*s,fill="#fb923c",outline="")
        else:
            c.create_oval(x-18*s,y-31*s,x+18*s,y+24*s,fill="#111827",outline=WHITE,width=2)
            c.create_oval(x-11*s,y-20*s,x+11*s,y+17*s,fill=WHITE,outline="")
            c.create_oval(x-9*s,y-26*s,x-5*s,y-22*s,fill=WHITE,outline="")
            c.create_oval(x+5*s,y-26*s,x+9*s,y-22*s,fill=WHITE,outline="")
            c.create_polygon(x-6*s,y-20*s,x+6*s,y-20*s,x,y-12*s,fill="#fb923c",outline="")
            c.create_line(x-12*s,y+22*s,x-21*s,y+29*s,fill="#fb923c",width=max(2,int(4*s)))
            c.create_line(x+12*s,y+22*s,x+21*s,y+29*s,fill="#fb923c",width=max(2,int(4*s)))

    def draw(self,diving=False):
        c=self.canvas; c.delete("all")
        w=max(1,c.winfo_width()); h=max(1,c.winfo_height())
        water_y=h*0.18
        c.create_rectangle(0,0,w,water_y,fill=WATER2,outline="")
        c.create_rectangle(0,water_y,w,h,fill=SKY,outline="")
        c.create_text(w*.5,water_y*.48,text="DIVE ZONE",fill=WHITE,font=("Segoe UI",max(10,int(w*.028)),"bold"))
        c.create_line(0,water_y,w,water_y,fill=WHITE,width=3)

        # Seven rising ice steps. Each wrong guess moves the penguin up exactly one.
        left=w*.16; usable=h*.68; bottom=h*.88
        step_h=usable/(self.max_steps+1)
        step_w=w*.57
        positions=[]
        for i in range(self.max_steps):
            y=bottom-i*step_h
            x=left+i*(w*.027)
            sw=step_w-i*(w*.035)
            c.create_rectangle(x,y,x+sw,y+step_h*.52,fill=STEP,outline=STEP_EDGE,width=2)
            c.create_text(x+9,y+step_h*.26,text=str(i+1),anchor="w",fill=WATER2,font=("Segoe UI",10,"bold"))
            positions.append((x+sw*.72,y-8))

        if diving:
            self.draw_penguin(w*.58,water_y+18,min(w,h)/650,True)
        else:
            idx=min(self.step,self.max_steps-1)
            if self.step==0:
                px,py=left+step_w*.72,bottom+step_h*.52-8
            else:
                px,py=positions[idx]
            self.draw_penguin(px,py,min(w,h)/650)

        c.create_text(w*.04,h*.95,text=f"Wrong guesses: {len(self.wrong)} / {self.max_steps}   " + " ".join(self.wrong),
                      anchor="w",fill="#0f172a",font=("Consolas",max(9,int(w*.021)),"bold"))

if __name__ == "__main__":
    root=tk.Tk(); Game(root); root.mainloop()
