SCS ONLINE CHESS - TWO PLAYER LOBBY

Run:
  python server.py
  python client.py

Lobby rules:
- Exactly two seats: Player 1 and Player 2.
- A third human join is rejected.
- Add AI fills only the remaining second seat.
- Add AI is rejected when both seats are occupied.
- Start requires exactly two occupied seats.

Board rules:
- Original 16x16 board size is unchanged.
- Two armies are centered on opposite sides of the board.
- Existing chat, timer, automatic timeout move, animation, and piece graphics remain.

TWO SETS / ALTERNATING TURNS
- Player 1 controls the first complete 16-piece set.
- Player 2 controls the second complete 16-piece set.
- No third or fourth army is created.
- The 16x16 board dimensions remain unchanged.
- Turns strictly alternate Player 1 -> Player 2 -> Player 1 while both kings remain active.
- Human-vs-human and human-vs-AI both use the same two-seat alternating order.

FOUR SETS / TWO SETS PER PLAYER
- There are four complete 16-piece sets, 64 pieces total.
- Player 1 controls both sets across the top side of the 16x16 board.
- Player 2 controls both sets across the bottom side of the 16x16 board.
- Player 1 and Player 2 still alternate turns one move at a time.
- Capturing one king does not eliminate that player; both kings for that player must be captured.
- Lobby remains limited to exactly two players (human/human or human/AI).
