import argparse
import json
import random
import socketserver
import string
import threading
import time

from rules import initial_pieces, at, legal, legal_squares

MOVE_SECONDS = 10
AI_THINK_SECONDS = 1.0
rooms = {}
rooms_lock = threading.RLock()


class Room:
    def __init__(self, code):
        self.code = code
        self.players = {}
        self.clients = {}
        self.bots = set()
        self.pieces = initial_pieces()
        self.active = []
        self.turn = 0
        self.started = False
        self.winner = None
        self.chat = []
        self.turn_started = None
        self.deadline = None
        self.turn_token = 0
        self.last_move = None

    def state(self):
        return {
            "type": "state",
            "code": self.code,
            "players": self.players,
            "bots": sorted(self.bots),
            "pieces": [piece.dict() for piece in self.pieces],
            "active": self.active,
            "turn": self.turn,
            "started": self.started,
            "winner": self.winner,
            "move_seconds": MOVE_SECONDS,
            "deadline": self.deadline,
            "server_time": time.time(),
            "last_move": self.last_move,
            "turn_order": [0, 1],
        }

    def broadcast(self, data):
        packet = (json.dumps(data) + "\n").encode()
        disconnected = []
        for player_id, handler in list(self.clients.items()):
            try:
                handler.request.sendall(packet)
            except OSError:
                disconnected.append(player_id)
        for player_id in disconnected:
            self.clients.pop(player_id, None)

    def broadcast_state(self):
        self.broadcast(self.state())

    def begin_turn(self):
        if not self.started or self.winner is not None or not self.active:
            self.deadline = None
            return
        self.turn_started = time.time()
        self.deadline = self.turn_started + MOVE_SECONDS
        self.turn_token += 1
        token = self.turn_token
        self.broadcast_state()
        threading.Thread(target=self._turn_worker, args=(token,), daemon=True).start()

    def _turn_worker(self, token):
        if self.turn in self.bots:
            time.sleep(AI_THINK_SECONDS)
            with rooms_lock:
                if token == self.turn_token and self.started and self.winner is None and self.turn in self.bots:
                    self.make_ai_move(self.turn, timeout=False)
            return

        remaining = max(0, (self.deadline or time.time()) - time.time())
        time.sleep(remaining)
        with rooms_lock:
            if token == self.turn_token and self.started and self.winner is None:
                self.broadcast({"type": "system", "text": f"Player {self.turn + 1} ran out of time. An automatic move was made."})
                self.make_ai_move(self.turn, timeout=True)

    def all_moves(self, player_id):
        moves = []
        values = {"pawn": 1, "knight": 3, "bishop": 3, "rook": 5, "queen": 9, "king": 50}
        for piece in self.pieces:
            if not piece.alive or piece.owner != player_id:
                continue
            for row, col in legal_squares(self.pieces, piece):
                target = at(self.pieces, row, col)
                capture_value = values.get(target.kind, 0) if target else 0
                score = capture_value * 100 + random.random() * 10
                moves.append((score, piece, row, col))
        return moves

    def make_ai_move(self, player_id, timeout=False):
        choices = self.all_moves(player_id)
        if not choices:
            self.broadcast({"type": "system", "text": f"Player {player_id + 1} has no legal move and is skipped."})
            self.advance_turn()
            return
        _score, piece, row, col = max(choices, key=lambda item: item[0])
        self.apply_move(player_id, piece, row, col)
        label = "Automatic" if timeout else "AI"
        move = self.last_move
        origin = square_name(*move["from"])
        destination = square_name(*move["to"])
        capture_text = f" and captured {move['capture']}" if move.get("capture") else ""
        self.broadcast({"type": "system", "text": f"{label} Player {player_id + 1} moved {piece.kind} {origin} to {destination}{capture_text}."})
        self.broadcast_state()
        if self.winner is None:
            self.begin_turn()

    def apply_move(self, player_id, piece, row, col):
        from_row, from_col = piece.row, piece.col
        target = at(self.pieces, row, col)
        self.last_move = {
            "player": player_id,
            "piece": piece.kind,
            "piece_id": piece.id,
            "from": [from_row, from_col],
            "to": [row, col],
            "capture": target.kind if target else None,
            "time": time.time(),
        }
        if target:
            target.alive = False
            if target.kind == "king":
                # Each player owns two complete sets. A player is eliminated only
                # after both kings belonging to that player have been captured.
                if not any(p.alive and p.owner == target.owner and p.kind == "king" for p in self.pieces):
                    self.active = [pid for pid in self.active if pid != target.owner]
                    for owned_piece in self.pieces:
                        if owned_piece.owner == target.owner:
                            owned_piece.alive = False
        piece.row, piece.col, piece.moved = row, col, True
        if len(self.active) == 1:
            self.winner = self.active[0]
            self.deadline = None
            self.turn_token += 1
        else:
            self.advance_turn(start_timer=False)

    def advance_turn(self, start_timer=True):
        if not self.active:
            return
        if self.turn in self.active:
            index = self.active.index(self.turn)
            self.turn = self.active[(index + 1) % len(self.active)]
        else:
            self.turn = self.active[0]
        if start_timer:
            self.begin_turn()


def square_name(row, col):
    return f"{chr(ord('A') + col)}{row + 1}"


def make_code():
    while True:
        code = "".join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
        if code not in rooms:
            return code


def send(handler, data):
    handler.request.sendall((json.dumps(data) + "\n").encode())


class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        self.room = None
        self.player_id = None
        while True:
            line = self.rfile.readline()
            if not line:
                break
            try:
                message = json.loads(line)
                with rooms_lock:
                    self.process(message)
            except Exception as error:
                try:
                    send(self, {"type": "error", "message": str(error)})
                except OSError:
                    break

    def process(self, message):
        message_type = message.get("type")
        if message_type == "create":
            room = Room(make_code())
            rooms[room.code] = room
            self.join(room, message.get("name", "Player"))
            return
        if message_type == "join":
            room = rooms.get(str(message.get("code", "")).strip().upper())
            if not room:
                send(self, {"type": "error", "message": "Room not found."})
            elif room.started:
                send(self, {"type": "error", "message": "Game already started."})
            else:
                self.join(room, message.get("name", "Player"))
            return
        if not self.room:
            send(self, {"type": "error", "message": "Join a room first."})
            return

        room = self.room
        if message_type == "add_bot":
            if room.started:
                send(self, {"type": "error", "message": "Add AI players before starting."})
                return
            free = next((pid for pid in range(2) if pid not in room.players), None)
            if free is None:
                send(self, {"type": "error", "message": "Two-player lobby is full."})
                return
            room.players[free] = f"AI Player {free + 1}"
            room.bots.add(free)
            room.broadcast_state()
        elif message_type == "start":
            room.active = sorted(room.players)
            if len(room.active) > 2:
                send(self, {"type": "error", "message": "This build supports exactly two players."})
                return
            if len(room.active) != 2:
                send(self, {"type": "error", "message": "Exactly two players are required."})
                return
            room.started = True
            # Two-player alternating turn order: Player 1, Player 2, repeat.
            room.turn = 0
            room.begin_turn()
        elif message_type == "legal":
            piece = next((p for p in room.pieces if p.id == message.get("piece")), None)
            moves = []
            if room.started and room.turn == self.player_id and piece and piece.owner == self.player_id:
                moves = legal_squares(room.pieces, piece)
            send(self, {"type": "legal", "piece": message.get("piece"), "moves": moves})
        elif message_type == "move":
            self.move(message)
        elif message_type == "chat":
            text = str(message.get("text", "")).strip()[:300]
            if text:
                chat = {"type": "chat", "player": self.player_id, "name": room.players[self.player_id], "text": text}
                room.chat.append(chat)
                room.chat = room.chat[-100:]
                room.broadcast(chat)

    def join(self, room, name):
        free = next((pid for pid in range(2) if pid not in room.players), None)
        if free is None:
            send(self, {"type": "error", "message": "Two-player lobby is full."})
            return
        self.room = room
        self.player_id = free
        room.players[free] = str(name).strip()[:20] or "Player"
        room.clients[free] = self
        send(self, {"type": "joined", "code": room.code, "player": free})
        for chat in room.chat:
            send(self, chat)
        room.broadcast_state()

    def move(self, message):
        room = self.room
        if not room.started or room.winner is not None or room.turn != self.player_id:
            send(self, {"type": "error", "message": "It is not your turn."})
            return
        if self.player_id in room.bots:
            return
        piece = next((p for p in room.pieces if p.id == message.get("piece")), None)
        row, col = message.get("row"), message.get("col")
        if not piece or piece.owner != self.player_id or not legal(room.pieces, piece, row, col):
            send(self, {"type": "error", "message": "Illegal move."})
            return
        if room.deadline is not None and time.time() > room.deadline:
            send(self, {"type": "error", "message": "Move time expired."})
            return
        room.turn_token += 1
        room.apply_move(self.player_id, piece, row, col)
        room.broadcast_state()
        if room.winner is None:
            room.begin_turn()

    def finish(self):
        with rooms_lock:
            if self.room and self.player_id is not None:
                self.room.clients.pop(self.player_id, None)
                self.room.broadcast({"type": "system", "text": f"Player {self.player_id + 1} disconnected."})


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=5050)
    args = parser.parse_args()
    with Server((args.host, args.port), Handler) as server:
        print(f"SCS server listening on {args.host}:{args.port}")
        server.serve_forever()
