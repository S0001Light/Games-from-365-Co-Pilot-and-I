import colorsys,json,math,random,socket,threading,tkinter as tk
from pathlib import Path
from tkinter import messagebox
PORT=5060;BG='#10253d';FELT='#075c40';GOLD='#ffd166';WHITE='#fffdf2';BLACK='#111';SIDES=('left','right','top','bottom')
def unwire(s):return tuple(map(int,s.split('-')))
class Client:
 def __init__(self,root):
  self.root=root;self.sock=None;self.pid=None;self.state=None;self.queue=[];self.lock=threading.Lock();self.images={};self.selected=None;self.art=[];self.last_move=0;self.load_images()
  root.title('All Fives - First Double Spinner');root.geometry('1280x900');root.configure(bg=BG);root.rowconfigure(1,weight=1);root.columnconfigure(0,weight=1)
  top=tk.Frame(root,bg=BG);top.grid(row=0,column=0,sticky='ew',padx=8,pady=6)
  self.host=tk.Entry(top,width=13);self.host.insert(0,'127.0.0.1');self.host.pack(side='left');self.port=tk.Entry(top,width=6);self.port.insert(0,str(PORT));self.port.pack(side='left');self.name=tk.Entry(top,width=11);self.name.insert(0,'Player');self.name.pack(side='left')
  for text,cmd in [('Connect',self.connect),('Create Room',lambda:self.send({'type':'create','name':self.name.get()})),('Join Room',self.join),('Add AI',lambda:self.send({'type':'add_bot'})),('Start Round',lambda:self.send({'type':'start'}))]:tk.Button(top,text=text,command=cmd).pack(side='left',padx=2)
  self.room=tk.Entry(top,width=8);self.room.pack(side='left');self.status=tk.StringVar(value='Not connected');tk.Label(top,textvariable=self.status,bg=BG,fg='white').pack(side='right')
  self.c=tk.Canvas(root,bg=FELT,highlightthickness=0);self.c.grid(row=1,column=0,sticky='nsew',padx=8);self.c.bind('<Configure>',lambda e:self.draw())
  bar=tk.Frame(root,bg=BG);bar.grid(row=2,column=0,sticky='ew',padx=8,pady=6)
  for side in SIDES:tk.Button(bar,text='PLAY '+side.upper(),command=lambda s=side:self.play(s),width=12).pack(side='left',padx=2)
  tk.Button(bar,text='AUTO DRAW / PASS',command=lambda:self.send({'type':'draw'}),width=16).pack(side='left',padx=8)
  self.msg=tk.StringVar(value='Connect and create a room.');tk.Label(bar,textvariable=self.msg,bg=BG,fg=GOLD,font=('Segoe UI',10,'bold')).pack(side='left')
  root.after(40,self.poll)
 def load_images(self):
  base=Path(__file__).resolve().parent;words=['zero','one','two','three','four','five','six']
  for a in range(7):
   for b in range(a,7):
    for name in (f'{words[a]}-{words[b]}.gif',f'{words[b]}-{words[a]}.gif'):
     for p in (base/'tiles'/name,base/name,base/'assets'/name):
      if p.is_file():
       try:self.images[(a,b)]=tk.PhotoImage(file=str(p));break
       except tk.TclError:pass
     if (a,b) in self.images:break
 def connect(self):
  try:self.sock=socket.create_connection((self.host.get().strip(),int(self.port.get())),5);self.sock.settimeout(None);threading.Thread(target=self.reader,daemon=True).start();self.status.set('Connected')
  except Exception as e:messagebox.showerror('Connect',str(e))
 def reader(self):
  try:
   for line in self.sock.makefile('r',encoding='utf-8'):
    if not line:break
    with self.lock:self.queue.append(json.loads(line))
  except (OSError,ValueError,json.JSONDecodeError):
   with self.lock:self.queue.append({'type':'disconnected'})
 def send(self,m):
  if not self.sock:self.msg.set('Connect first.');return
  try:self.sock.sendall((json.dumps(m)+'\n').encode())
  except OSError:self.msg.set('Connection closed.')
 def join(self):self.send({'type':'join','code':self.room.get(),'name':self.name.get()})
 def poll(self):
  with self.lock:q,self.queue=self.queue,[]
  for m in q:
   if m.get('type')=='joined':self.pid=m['player'];self.room.delete(0,'end');self.room.insert(0,m['code']);self.status.set('Room '+m['code'])
   elif m.get('type')=='state':
    self.state=m;self.msg.set(m.get('last',''));move=m.get('move',0)
    while self.last_move<move:self.add_triangles();self.last_move+=1
    self.selected=None;self.draw()
   elif m.get('type')=='error':self.msg.set('ERROR: '+m.get('message',''))
   elif m.get('type')=='disconnected':self.status.set('Disconnected')
  self.root.after(40,self.poll)
 def add_triangles(self):
  rng=random.Random(self.last_move+731);base=rng.random();layer=[]
  for _ in range(rng.randint(18,34)):
   cx,cy=rng.uniform(.08,.92),rng.uniform(.10,.70);size=rng.uniform(.012,.04);ang=rng.random()*math.tau;pts=[]
   for k in range(3):
    a=ang+k*math.tau/3;pts.extend((cx+math.cos(a)*size,cy+math.sin(a)*size))
   rgb=colorsys.hsv_to_rgb((base+rng.uniform(-.18,.18))%1,rng.uniform(.35,.8),rng.uniform(.45,.95));color='#%02x%02x%02x'%tuple(int(x*255) for x in rgb);layer.append((pts,color))
  self.art.append(layer);self.art=self.art[-35:]
 def draw_art(self,w,h):
  for layer in self.art:
   for pts,color in layer:
    xy=[v*(w if i%2==0 else h) for i,v in enumerate(pts)];self.c.create_polygon(*xy,fill=color,outline='',stipple='gray50')
 def domino(self,x,y,t,scale=.8,vertical=False,tag=None):
  img=self.images.get(tuple(sorted(t)))
  if img and not vertical and scale>=.75:self.c.create_image(x,y,image=img,tags=tag);return
  long,short=78*scale,40*scale;w,h=(short,long) if vertical else (long,short)
  self.c.create_rectangle(x-w/2,y-h/2,x+w/2,y+h/2,fill=WHITE,outline=BLACK,width=3,tags=tag)
  if vertical:self.c.create_line(x-w/2,y,x+w/2,y,fill=BLACK,width=2,tags=tag);p1=(x,y-h*.25);p2=(x,y+h*.25)
  else:self.c.create_line(x,y-h/2,x,y+h/2,fill=BLACK,width=2,tags=tag);p1=(x-w*.25,y);p2=(x+w*.25,y)
  f=('Arial',max(9,int(17*scale)),'bold');self.c.create_text(*p1,text=str(t[0]),font=f,fill=BLACK,tags=tag);self.c.create_text(*p2,text=str(t[1]),font=f,fill=BLACK,tags=tag)
 def draw(self):
  c=self.c;c.delete('all');w=max(850,c.winfo_width());h=max(650,c.winfo_height());self.draw_art(w,h)
  if not self.state:c.create_text(w/2,h/2,text='FIRST DOUBLE SPINNER DOMINOES',fill='white',font=('Segoe UI',24,'bold'));return
  s=self.state;players=s.get('players',{});scores=s.get('scores',{});bots=set(s.get('bots',[]))
  text='   '.join(f"{n}{' [AI]' if int(p) in bots else ''}: {scores.get(p,scores.get(int(p),0))}" for p,n in sorted(players.items(),key=lambda z:int(z[0])))
  c.create_text(w/2,24,text=f"ROOM {s['code']}  ROUND {s['round']}  STOCK {s['stock']}  FIRST TO {s.get('target',150)}  GIF {len(self.images)}/28",fill='white',font=('Segoe UI',12,'bold'));c.create_text(w/2,50,text=text,fill=GOLD,font=('Consolas',12,'bold'))
  cx,cy=w/2,(h-190)/2+55;spinner=unwire(s['spinner']) if s.get('spinner') else None
  if spinner:self.domino(cx,cy,spinner,1.0,True);c.create_text(cx,cy-58,text='ONLY SPINNER',fill=GOLD,font=('Segoe UI',9,'bold'))
  arms={k:[unwire(x) for x in v] for k,v in s.get('arms',{}).items()}
  # Zoom farther out as any spinner arm grows. Reserve the lower 190 pixels for the full hand.
  horizontal=max(1,len(arms.get('left',[])),len(arms.get('right',[])))
  vertical=max(1,len(arms.get('top',[])),len(arms.get('bottom',[])))
  board_w=max(360,w-150);board_h=max(260,h-300)
  scale=max(.30,min(.72,board_w/(horizontal*185+150),board_h/(vertical*150+160)))
  step=max(31,76*scale)
  # Arm layout differences: normal tiles point along an arm; doubles turn crosswise.
  for i,t in enumerate(arms.get('left',[])):
   self.domino(cx-step*(i+1),cy,t,scale,vertical=(t[0]==t[1]))
  for i,t in enumerate(arms.get('right',[])):
   self.domino(cx+step*(i+1),cy,t,scale,vertical=(t[0]==t[1]))
  for i,t in enumerate(arms.get('top',[])):
   self.domino(cx,cy-step*(i+1),t,scale,vertical=(t[0]!=t[1]))
  for i,t in enumerate(arms.get('bottom',[])):
   self.domino(cx,cy+step*(i+1),t,scale,vertical=(t[0]!=t[1]))
  ends=s.get('ends',{});active={side:bool(s.get('arms',{}).get(side,[])) for side in SIDES}
  label_gap=max(48,step*(horizontal+1));vlabel_gap=max(55,step*(vertical+1))
  c.create_text(max(45,cx-label_gap),cy+22,text=f"LEFT {ends.get('left','-')}{'' if active.get('left') else ' (not counted)'}",fill='white',font=('Segoe UI',9,'bold'))
  c.create_text(min(w-45,cx+label_gap),cy+22,text=f"RIGHT {ends.get('right','-')}{'' if active.get('right') else ' (not counted)'}",fill='white',font=('Segoe UI',9,'bold'))
  c.create_text(cx+46,max(78,cy-vlabel_gap),text=f"TOP {ends.get('top','-')}{'' if active.get('top') else ' (not counted)'}",fill='white',font=('Segoe UI',9,'bold'))
  c.create_text(cx+56,min(h-205,cy+vlabel_gap),text=f"BOTTOM {ends.get('bottom','-')}{'' if active.get('bottom') else ' (not counted)'}",fill='white',font=('Segoe UI',9,'bold'))
  c.create_text(18,72,anchor='w',text=f"BOARD ZOOM {scale:.2f}  |  doubles crosswise, regular tiles follow each arm",fill='#b8f2e6',font=('Segoe UI',9,'bold'))
  c.create_rectangle(16,h-180,w-16,h-16,fill='#0b4936',outline=GOLD,width=3);raw=s.get('hands',{}).get(str(self.pid),[]);hand=[unwire(x) for x in raw if x]
  c.create_text(28,h-163,anchor='w',text=f'FULL DEALT HAND: {len(hand)} TILES - SELECT ONE, THEN PRESS A SIDE BUTTON',fill=GOLD,font=('Segoe UI',11,'bold'))
  gap=min(105,max(68,(w-90)/max(1,len(hand))));start=w/2-(len(hand)-1)*gap/2
  for i,t in enumerate(hand):
   x=start+i*gap;y=h-82;tag=f'h{i}';legal=[side for side,val in ends.items() if val in t]
   if legal:c.create_rectangle(x-45,y-31,x+45,y+31,outline='#7CFC00',width=3,tags=tag)
   if self.selected==i:c.create_rectangle(x-49,y-35,x+49,y+35,outline=GOLD,width=4,tags=tag)
   self.domino(x,y,t,.88,False,tag);c.tag_bind(tag,'<Button-1>',lambda e,j=i:self.select(j));c.create_text(x,h-38,text='/'.join(x[0].upper() for x in legal) if legal else 'BLOCKED',fill='#7CFC00' if legal else '#bbb',font=('Segoe UI',8,'bold'))
 def select(self,i):self.selected=i;self.draw()
 def play(self,side):
  if not self.state or self.state.get('turn')!=self.pid or self.selected is None:return
  hand=[x for x in self.state.get('hands',{}).get(str(self.pid),[]) if x]
  if self.selected<len(hand):self.send({'type':'play','tile':hand[self.selected],'side':side})
if __name__=='__main__':r=tk.Tk();Client(r);r.mainloop()
