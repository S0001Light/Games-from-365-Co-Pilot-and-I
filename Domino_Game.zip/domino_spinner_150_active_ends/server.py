import argparse, json, random, socketserver, string, threading

PORT=5060
TARGET_SCORE=150
LOCK=threading.RLock()
ROOMS={}
SIDES=('left','right','top','bottom')

def all_tiles(): return [(a,b) for a in range(7) for b in range(a,7)]
def wire(t): return f'{t[0]}-{t[1]}'
def unwire(s): return tuple(map(int,s.split('-')))
def code(): return ''.join(random.choice(string.ascii_uppercase+string.digits) for _ in range(6))
def send(h,m): h.request.sendall((json.dumps(m)+'\n').encode('utf-8'))

class Room:
 def __init__(self,c):
  self.code=c;self.players={};self.clients={};self.bots=set();self.hands={};self.stock=[]
  self.spinner=None;self.arms={s:[] for s in SIDES};self.scores={};self.turn=None
  self.started=False;self.round=0;self.move=0;self.last='Create or join a room.'
 def endpoint(self,side):
  return self.arms[side][-1][1] if self.arms[side] else self.spinner[0]
 def endpoints(self): return {s:self.endpoint(s) for s in SIDES}
 def scoring_ends(self):
  # The spinner itself is not counted as four open sixes. An arm contributes
  # to the All Fives total only after at least one tile has been played on it.
  return {s:self.endpoint(s) for s in SIDES if self.arms[s]}
 def state(self,viewer):
  hands={str(p):([wire(t) for t in h] if p==viewer else [None]*len(h)) for p,h in self.hands.items()}
  return {'type':'state','code':self.code,'players':self.players,'bots':sorted(self.bots),'hands':hands,
   'stock':len(self.stock),'spinner':wire(self.spinner) if self.spinner else None,
   'arms':{s:[wire(t) for t in self.arms[s]] for s in SIDES},'ends':self.endpoints() if self.spinner else {},
   'scores':self.scores,'target':TARGET_SCORE,'turn':self.turn,'started':self.started,'round':self.round,'move':self.move,'last':self.last}
 def states(self):
  for p,h in list(self.clients.items()):
   try:send(h,self.state(p))
   except OSError:self.clients.pop(p,None)
 def nextp(self,p):
  ids=sorted(self.players);return ids[(ids.index(p)+1)%len(ids)]
 def legal_sides(self,t):return [s for s in SIDES if self.endpoint(s) in t]
 def add_bot(self):
  if self.started:return False,'Add AI before starting.'
  p=next((x for x in range(4) if x not in self.players),None)
  if p is None:return False,'Room full.'
  self.players[p]=f'AI {p+1}';self.bots.add(p);self.scores.setdefault(p,0);self.last=f'{self.players[p]} joined.';self.states();return True,''
 def start(self):
  if len(self.players)<2:return False,'Need at least two seats.'
  deck=all_tiles();random.shuffle(deck);self.hands={p:[] for p in self.players};self.arms={s:[] for s in SIDES};self.round+=1;self.move=0
  n=7 if len(self.players)==2 else 5
  for _ in range(n):
   for p in sorted(self.players):self.hands[p].append(deck.pop())
  self.stock=deck;owner=next((p for p,h in self.hands.items() if (6,6) in h),None)
  if owner is None:
   owner=min(self.players);self.stock.remove((6,6));self.stock.append(self.hands[owner].pop());self.hands[owner].append((6,6))
  self.hands[owner].remove((6,6));self.spinner=(6,6);self.started=True;self.turn=self.nextp(owner);self.move=1
  self.last=f'{self.players[owner]} played the first double 6-6 as the only spinner.';self.states();self.schedule_bot();return True,''
 def score(self,p):
  ends=self.scoring_ends();total=sum(ends.values());points=total if total and total%5==0 else 0
  self.scores[p]=self.scores.get(p,0)+points;return ends,total,points
 def play(self,p,t,side):
  if not self.started:return False,'Round not running.'
  if p!=self.turn:return False,'It is not your turn.'
  if t not in self.hands.get(p,[]):return False,'Tile not in hand.'
  if side not in SIDES:return False,'Choose LEFT, RIGHT, TOP, or BOTTOM.'
  end=self.endpoint(side)
  if end not in t:return False,f'{wire(t)} cannot play on {side.upper()} end {end}.'
  a,b=t;placed=(a,b) if a==end else (b,a);self.arms[side].append(placed);self.hands[p].remove(t);self.move+=1
  ends,total,points=self.score(p);self.last=f'{self.players[p]} played {wire(t)} on {side.upper()}. Active ends {ends}; total {total}; scored {points}; match total {self.scores[p]}.'
  if not self.hands[p]:
   # Hand-end award: total all opponents' remaining pips, rounded to nearest 5.
   remaining=sum(a+b for op,h in self.hands.items() if op!=p for a,b in h)
   hand_award=int(5*((remaining+2)//5)) if remaining else 0
   self.scores[p]=self.scores.get(p,0)+hand_award
   self.started=False;self.turn=None
   self.last+=f' {self.players[p]} dominoes! Remaining pips {remaining}, hand award {hand_award}; total {self.scores[p]}.'
   if self.scores[p]>=TARGET_SCORE:self.last+=f' {self.players[p]} WINS THE GAME at {self.scores[p]} points (target {TARGET_SCORE}).'
   else:self.last+=f' Start the next round. First to {TARGET_SCORE} wins.'
   self.states();return True,''
  self.turn=self.nextp(p);self.states();self.schedule_bot();return True,''
 def draw(self,p):
  if not self.started:return False,'Round not running.'
  if p!=self.turn:return False,'It is not your turn.'
  if any(self.legal_sides(t) for t in self.hands[p]):return False,'A playable tile is already in your hand.'
  drawn=0
  while self.stock:
   t=self.stock.pop();self.hands[p].append(t);drawn+=1;self.last=f'{self.players[p]} drew {drawn} tile(s).';self.states()
   sides=self.legal_sides(t)
   if sides:return self.play(p,t,sides[0])
  self.last=f'{self.players[p]} passes.';self.turn=self.nextp(p);self.states();self.schedule_bot();return True,''
 def schedule_bot(self):
  if self.started and self.turn in self.bots:
   z=threading.Timer(.55,self.bot,args=(self.turn,));z.daemon=True;z.start()
 def bot(self,p):
  with LOCK:
   if not self.started or self.turn!=p:return
   opts=[]
   for t in self.hands[p]:
    for side in self.legal_sides(t):
     end=self.endpoint(side);other=t[1] if t[0]==end else t[0];future=self.endpoints();future[side]=other;total=sum(future.values());pts=total if total and total%5==0 else 0
     opts.append((pts,sum(t),t,side))
   if opts:
    _,_,t,side=max(opts,key=lambda x:(x[0],x[1]));self.play(p,t,side)
   else:self.draw(p)

class Handler(socketserver.StreamRequestHandler):
 def handle(self):
  self.room=None;self.pid=None
  try:
   while True:
    try:line=self.rfile.readline()
    except (ConnectionResetError,ConnectionAbortedError,BrokenPipeError,OSError):break
    if not line:break
    try:
     with LOCK:self.process(json.loads(line))
    except Exception as e:
     try:send(self,{'type':'error','message':str(e)})
     except OSError:break
  finally:
   with LOCK:
    if self.room is not None and self.pid is not None:self.room.clients.pop(self.pid,None)
 def process(self,m):
  typ=m.get('type')
  if typ=='create':
   c=code()
   while c in ROOMS:c=code()
   ROOMS[c]=Room(c);return self.join(ROOMS[c],m.get('name','Player'))
  if typ=='join':
   r=ROOMS.get(str(m.get('code','')).upper())
   if not r:return send(self,{'type':'error','message':'Room not found.'})
   if r.started:return send(self,{'type':'error','message':'Round in progress.'})
   return self.join(r,m.get('name','Player'))
  if not self.room:return send(self,{'type':'error','message':'Create or join a room first.'})
  if typ=='add_bot':ok,msg=self.room.add_bot()
  elif typ=='start':ok,msg=self.room.start()
  elif typ=='play':ok,msg=self.room.play(self.pid,unwire(m['tile']),m.get('side'))
  elif typ=='draw':ok,msg=self.room.draw(self.pid)
  else:return
  if not ok:send(self,{'type':'error','message':msg})
 def join(self,r,name):
  p=next((x for x in range(4) if x not in r.players),None)
  if p is None:return send(self,{'type':'error','message':'Room full.'})
  self.room=r;self.pid=p;r.players[p]=str(name)[:18] or 'Player';r.clients[p]=self;r.scores.setdefault(p,0);send(self,{'type':'joined','player':p,'code':r.code});r.states()
class Server(socketserver.ThreadingTCPServer):allow_reuse_address=True;daemon_threads=True
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--host',default='0.0.0.0');ap.add_argument('--port',type=int,default=PORT);a=ap.parse_args()
 with Server((a.host,a.port),Handler) as s:print(f'Domino room server {a.host}:{a.port}');s.serve_forever()
