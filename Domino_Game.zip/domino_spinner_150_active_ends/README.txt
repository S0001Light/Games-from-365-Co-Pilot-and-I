FIRST DOUBLE SPINNER DOMINOES

Run server.py, then client.py. Connect, Create Room, Add AI, Start Round.
Select a hand tile, then press PLAY LEFT, PLAY RIGHT, PLAY TOP, or PLAY BOTTOM.
Only the first double, forced 6-6, is the four-way spinner. Later doubles are
ordinary tiles on one arm. If no tile can play, AUTO DRAW / PASS draws until a
playable tile is found and plays it automatically. Each move adds a new layer of
random colored triangles. The full dealt hand stays visible at the bottom.

ZOOM AND LAYOUT UPDATE
- The playable board now zooms down as far as 30% when an arm grows.
- Horizontal and vertical arm lengths are measured separately.
- Regular tiles point along their selected arm.
- Doubles after the spinner are laid crosswise to make them visually different.
- End labels move outward with each arm while staying inside the board.
- The full hand panel remains fixed and readable at the bottom.

150-POINT GAME SCORING
- First player to 150 or more points wins the complete game.
- Normal All Fives board scores are awarded only in multiples of 5.
- Scores carry over between rounds.
- When a player dominoes, all opponents' remaining pips are totaled.
- That remaining-pip total is rounded to the nearest multiple of 5 and awarded to the player who dominoed.
- If nobody has reached 150, click Start Round to deal the next hand.

ACTIVE-SPINNER-END SCORING FIX
- The first double remains the only spinner.
- The spinner is not automatically counted as four open ends.
- A left, right, top, or bottom arm enters the scoring total only after a tile
  has actually been played on that arm.
- Inactive spinner sides remain legal play locations but are labeled not counted.
- Once activated, the exposed endpoint of that arm is included in multiples-of-5 scoring.


BE AWARE TILES ARE TURNED DIFFERENTLY ALTHOUGH WORK ><