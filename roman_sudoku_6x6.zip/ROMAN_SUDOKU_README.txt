ROMAN NUMERAL SUDOKU 6x6

Run:
  python roman_sudoku.py

Rules:
  - Use Roman numerals I, II, III, IV, V, VI.
  - Each row contains I through VI once.
  - Each column contains I through VI once.
  - Each 2x3 box contains I through VI once.

Controls:
  - Click an empty square, then click I through VI.
  - Number keys 1 through 6 also work.
  - Clear removes an entry.
  - Check validates the puzzle.
  - New Game generates another puzzle.

The generator keeps removing clues only while the puzzle has exactly one solution.
