import random
import tkinter as tk
from tkinter import messagebox

N = 6
ROMAN = {1:'I', 2:'II', 3:'III', 4:'IV', 5:'V', 6:'VI'}
VALUES = {v:k for k,v in ROMAN.items()}
BG = '#0b1220'
PANEL = '#111c30'
GIVEN = '#e2e8f0'
USER = '#38bdf8'
BAD = '#ef4444'
GOOD = '#22c55e'
SELECT = '#facc15'


def pattern(r, c):
    # 2x3 boxes
    return (c + 3 * (r % 2) + r // 2) % N


def shuffled(seq):
    seq = list(seq)
    random.shuffle(seq)
    return seq


def make_solution():
    rows = [g * 2 + r for g in shuffled(range(3)) for r in shuffled(range(2))]
    cols = [g * 3 + c for g in shuffled(range(2)) for c in shuffled(range(3))]
    nums = shuffled(range(1, 7))
    return [[nums[pattern(r, c)] for c in cols] for r in rows]


def count_solutions(board, limit=2):
    best = None
    best_opts = None
    for r in range(N):
        for c in range(N):
            if board[r][c] != 0:
                continue
            used = set(board[r])
            used |= {board[x][c] for x in range(N)}
            br, bc = (r // 2) * 2, (c // 3) * 3
            used |= {board[x][y] for x in range(br, br + 2) for y in range(bc, bc + 3)}
            opts = [n for n in range(1, 7) if n not in used]
            if not opts:
                return 0
            if best is None or len(opts) < len(best_opts):
                best, best_opts = (r, c), opts
    if best is None:
        return 1
    r, c = best
    total = 0
    for n in best_opts:
        board[r][c] = n
        total += count_solutions(board, limit)
        board[r][c] = 0
        if total >= limit:
            return total
    return total


def make_puzzle(solution, remove=20):
    puzzle = [row[:] for row in solution]
    cells = shuffled([(r,c) for r in range(N) for c in range(N)])
    removed = 0
    for r,c in cells:
        if removed >= remove:
            break
        old = puzzle[r][c]
        puzzle[r][c] = 0
        test = [row[:] for row in puzzle]
        if count_solutions(test) == 1:
            removed += 1
        else:
            puzzle[r][c] = old
    return puzzle


class RomanSudoku:
    def __init__(self, root):
        self.root = root
        root.title('Roman Numeral Sudoku 6x6')
        root.configure(bg=BG)
        root.minsize(600, 700)
        root.geometry('760x850')
        root.rowconfigure(1, weight=1)
        root.columnconfigure(0, weight=1)

        header = tk.Frame(root, bg=PANEL, padx=12, pady=10)
        header.grid(row=0, column=0, sticky='ew')
        tk.Label(header, text='Roman Numeral Sudoku', bg=PANEL, fg='white',
                 font=('Segoe UI', 18, 'bold')).pack(side='left')
        tk.Button(header, text='New Game', command=self.new_game).pack(side='right')
        tk.Button(header, text='Check', command=self.check, padx=15).pack(side='right', padx=8)

        main = tk.Frame(root, bg=BG)
        main.grid(row=1, column=0, sticky='nsew', padx=14, pady=14)
        main.rowconfigure(0, weight=1)
        main.columnconfigure(0, weight=1)

        self.canvas = tk.Canvas(main, bg=BG, highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        self.canvas.bind('<Configure>', lambda e: self.draw())
        self.canvas.bind('<Button-1>', self.click)

        controls = tk.Frame(root, bg=PANEL, padx=10, pady=10)
        controls.grid(row=2, column=0, sticky='ew')
        self.number_buttons = []
        for value in range(1,7):
            b = tk.Button(controls, text=ROMAN[value], font=('Segoe UI', 13, 'bold'),
                          command=lambda n=value: self.enter(n), width=4)
            b.pack(side='left', expand=True, padx=3)
            self.number_buttons.append(b)
        tk.Button(controls, text='Clear', command=lambda: self.enter(0)).pack(side='left', padx=5)

        self.status = tk.StringVar()
        tk.Label(root, textvariable=self.status, bg=BG, fg='#cbd5e1', pady=8,
                 font=('Segoe UI', 10)).grid(row=3, column=0, sticky='ew')

        root.bind('<Key>', self.keypress)
        self.selected = None
        self.solution = None
        self.puzzle = None
        self.board = None
        self.fixed = None
        self.new_game()

    def new_game(self):
        self.solution = make_solution()
        self.puzzle = make_puzzle(self.solution, 20)
        self.board = [row[:] for row in self.puzzle]
        self.fixed = [[self.puzzle[r][c] != 0 for c in range(N)] for r in range(N)]
        self.selected = next(((r,c) for r in range(N) for c in range(N) if not self.fixed[r][c]), None)
        self.status.set('Fill each row, column, and 2x3 box with I through VI exactly once.')
        self.draw()

    def geom(self):
        w, h = max(1,self.canvas.winfo_width()), max(1,self.canvas.winfo_height())
        size = min(w, h) * 0.93
        cell = size / N
        return cell, (w-size)/2, (h-size)/2, size

    def draw(self):
        self.canvas.delete('all')
        if self.board is None: return
        cell, ox, oy, size = self.geom()
        for r in range(N):
            for c in range(N):
                x1,y1=ox+c*cell,oy+r*cell
                fill = '#172033' if (r//2+c//3)%2==0 else '#101827'
                if self.selected == (r,c): fill = '#3f3a1c'
                self.canvas.create_rectangle(x1,y1,x1+cell,y1+cell,fill=fill,outline='#334155')
                v=self.board[r][c]
                if v:
                    color = GIVEN if self.fixed[r][c] else USER
                    self.canvas.create_text(x1+cell/2,y1+cell/2,text=ROMAN[v],fill=color,
                                            font=('Times New Roman',max(14,int(cell*.34)),'bold'))
        for i in range(N+1):
            width = 5 if i in (0,2,4,6) else 1
            self.canvas.create_line(ox,oy+i*cell,ox+size,oy+i*cell,fill='white' if width>1 else '#475569',width=width)
            width = 5 if i in (0,3,6) else 1
            self.canvas.create_line(ox+i*cell,oy,ox+i*cell,oy+size,fill='white' if width>1 else '#475569',width=width)

    def click(self, event):
        cell,ox,oy,size=self.geom()
        c=int((event.x-ox)//cell); r=int((event.y-oy)//cell)
        if 0<=r<N and 0<=c<N:
            self.selected=(r,c)
            self.draw()

    def enter(self, value):
        if not self.selected: return
        r,c=self.selected
        if self.fixed[r][c]:
            self.status.set('That Roman numeral is part of the puzzle and cannot be changed.')
            return
        self.board[r][c]=value
        self.status.set('')
        self.draw()
        if all(self.board[r][c] for r in range(N) for c in range(N)):
            self.check()

    def keypress(self, event):
        keys={'1':1,'2':2,'3':3,'4':4,'5':5,'6':6,
              'i':1,'I':1,'v':5,'V':5}
        if event.keysym in ('BackSpace','Delete','0'):
            self.enter(0)
        elif event.char in keys:
            self.enter(keys[event.char])

    def valid(self):
        needed=set(range(1,7))
        for r in range(N):
            if set(self.board[r]) != needed: return False
        for c in range(N):
            if {self.board[r][c] for r in range(N)} != needed: return False
        for br in range(0,N,2):
            for bc in range(0,N,3):
                if {self.board[r][c] for r in range(br,br+2) for c in range(bc,bc+3)} != needed:
                    return False
        return True

    def check(self):
        if self.valid():
            self.status.set('Solved! Every row, column, and 2x3 box contains I through VI.')
            messagebox.showinfo('Roman Sudoku', 'Solved!')
        else:
            wrong=sum(1 for r in range(N) for c in range(N) if self.board[r][c] and self.board[r][c] != self.solution[r][c])
            empty=sum(1 for r in range(N) for c in range(N) if not self.board[r][c])
            self.status.set(f'Not solved yet. Empty cells: {empty}. Incorrect entries: {wrong}.')

if __name__ == '__main__':
    root=tk.Tk()
    RomanSudoku(root)
    root.mainloop()
