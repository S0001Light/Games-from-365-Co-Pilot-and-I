WRITERS JUMBLER PINBALL - SPREAD FLIPPERS / CENTER DRAIN

Run:
  python writers_jumbler_pinball_center_drain.py

TABLE CHANGES
  - Left and right flipper pivots are spread farther apart.
  - Flippers point inward toward the center drain.
  - The bottom of the table is closed with two floor shelves.
  - The only fall-through opening is the center gap between the flippers.
  - Balls reaching the lower-left or lower-right floor bounce back into play.
  - Red rails show exactly where the bottom floor is solid.
  - The center opening is labeled DRAIN.
  - Full-height shooter ramp and upper-ramp launch are retained.

CONTROLS
  A or Left Arrow   Left flipper
  D or Right Arrow  Right flipper
  Space             Launch
  P                 Pause
  Enter             Submit word
