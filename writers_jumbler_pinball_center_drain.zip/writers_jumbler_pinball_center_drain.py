from __future__ import annotations

import math
import random
import string
import tkinter as tk
from dataclasses import dataclass
from tkinter import messagebox

WIDTH = 760
HEIGHT = 920
FPS_MS = 16
BALL_RADIUS = 11
MAX_RACK = 12
DRAIN_LEFT = 335
DRAIN_RIGHT = 425
FLOOR_Y = 875

BG = "#07111f"
BOARD = "#0b1728"
LINE = "#64748b"
CYAN = "#22d3ee"
YELLOW = "#facc15"
GREEN = "#22c55e"
RED = "#ef4444"
PURPLE = "#a78bfa"
WHITE = "#f8fafc"

COMMON_WORDS = {
    "ACE", "ACT", "AGE", "AIR", "ANT", "APE", "ARC", "ARM", "ART", "ASH", "ASK",
    "BAD", "BAG", "BAR", "BAT", "BED", "BEE", "BIG", "BIT", "BOX", "BOY", "BUS",
    "CAN", "CAP", "CAR", "CAT", "COW", "CRY", "CUP", "CUT",
    "DAY", "DEN", "DOG", "DOT", "DRY",
    "EAR", "EAT", "EGG", "END", "EYE",
    "FAR", "FAT", "FIN", "FIT", "FIX", "FLY", "FOX", "FUN",
    "GAP", "GAS", "GET", "GOD", "GUM", "GUN", "GUY",
    "HAT", "HEN", "HIT", "HOT", "HOW",
    "ICE", "INK",
    "JAM", "JAR", "JET", "JOB", "JOY",
    "KEY", "KID",
    "LAP", "LEG", "LET", "LID", "LOG", "LOW",
    "MAN", "MAP", "MAT", "MEN", "MIX", "MUD",
    "NET", "NEW", "NOD", "NOT", "NOW", "NUT",
    "OAK", "ODD", "OLD", "ONE", "OUT", "OWL",
    "PAN", "PEN", "PET", "PIE", "PIG", "PIN", "POT",
    "RAG", "RAN", "RAT", "RED", "RIB", "ROD", "RUN",
    "SAD", "SAT", "SAW", "SEA", "SET", "SIT", "SIX", "SKY", "SUN",
    "TAG", "TAN", "TAP", "TEA", "TEN", "THE", "TIN", "TOE", "TOP", "TOY", "TWO",
    "USE",
    "VAN",
    "WAR", "WET", "WHO", "WHY", "WIN",
    "YES", "YOU",
    "ZAP", "ZIP", "ZOO",
    "BALL", "BELL", "BIRD", "BLUE", "BOOK", "BUMP",
    "CARD", "CART", "COLD", "DARK", "DESK", "DOOR", "DRAW",
    "EASY", "EDGE", "FIRE", "FISH", "GAME", "GLOW", "GOOD", "GRID",
    "HAND", "HARD", "HIT", "HOME", "JUMP", "KING", "LEFT", "LIFE", "LIGHT", "LINE",
    "MAKE", "MOVE", "OPEN", "PLAY", "RACK", "READ", "RIGHT", "RING", "ROLL",
    "SAVE", "SCORE", "STAR", "STOP", "TIME", "TURN", "WORD", "WRITE",
    "BALLS", "BOARD", "BONUS", "BUILD", "CLEAR", "DREAM", "FLIPPER", "JUMBLE",
    "LETTER", "PINBALL", "PLAYER", "STORY", "WRITER", "WRITING"
}

LETTER_WEIGHTS = "EEEEEEEEEEEEAAAAAAAARRRRRRIIIIIIIIOOOOOOTTTTTTNNNNNNSSSSSLLLLDDDDGGGBCMPFHVWYJKQXZ"
LETTER_VALUE = {
    **{c: 1 for c in "AEILNORSTU"},
    **{c: 2 for c in "DG"},
    **{c: 3 for c in "BCMP"},
    **{c: 4 for c in "FHVWY"},
    "K": 5, "J": 8, "X": 8, "Q": 10, "Z": 10
}


@dataclass
class Ball:
    x: float
    y: float
    vx: float
    vy: float
    active: bool = True


@dataclass
class Bumper:
    x: float
    y: float
    radius: float
    letter: str
    flash: int = 0
    cooldown: int = 0


class WritersJumblerPinball:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("Writers Jumbler Pinball")
        root.configure(bg=BG)
        root.geometry("1180x900")
        root.minsize(760, 620)
        root.rowconfigure(1, weight=1)
        root.columnconfigure(0, weight=1)

        self.score = 0
        self.high_score = 0
        self.lives = 3
        self.multiplier = 1
        self.rack: list[str] = []
        self.word = ""
        self.running = False
        self.paused = False
        self.left_down = False
        self.right_down = False
        self.ball: Ball | None = None
        self.in_launch_lane = True
        self.bumpers: list[Bumper] = []
        self.stars = []
        self.scale_x = 1.0
        self.scale_y = 1.0

        self.score_text = tk.StringVar()
        self.lives_text = tk.StringVar()
        self.multiplier_text = tk.StringVar()
        self.rack_text = tk.StringVar()
        self.word_text = tk.StringVar()
        self.message_text = tk.StringVar()

        self.build_ui()
        self.bind_keys()
        self.new_game()
        self.loop()

    def build_ui(self):
        header = tk.Frame(self.root, bg="#0d1b2e", padx=12, pady=8)
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(8, weight=1)
        tk.Label(header, text="Writers Jumbler Pinball", bg="#0d1b2e", fg=WHITE,
                 font=("Segoe UI", 18, "bold")).grid(row=0, column=0, padx=(0, 18))
        tk.Label(header, textvariable=self.score_text, bg="#0d1b2e", fg=YELLOW,
                 font=("Consolas", 13, "bold")).grid(row=0, column=1, padx=7)
        tk.Label(header, textvariable=self.lives_text, bg="#0d1b2e", fg=CYAN,
                 font=("Consolas", 13, "bold")).grid(row=0, column=2, padx=7)
        tk.Label(header, textvariable=self.multiplier_text, bg="#0d1b2e", fg=GREEN,
                 font=("Consolas", 13, "bold")).grid(row=0, column=3, padx=7)
        tk.Button(header, text="New Game", command=self.new_game).grid(row=0, column=4, padx=4)
        tk.Button(header, text="Launch", command=self.launch).grid(row=0, column=5, padx=4)
        tk.Button(header, text="Pause", command=self.toggle_pause).grid(row=0, column=6, padx=4)

        pane = tk.PanedWindow(self.root, orient="horizontal", sashwidth=7, bg=BG)
        pane.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)

        board_frame = tk.Frame(pane, bg=BG)
        board_frame.rowconfigure(0, weight=1)
        board_frame.columnconfigure(0, weight=1)
        self.canvas = tk.Canvas(board_frame, bg=BOARD, highlightthickness=2,
                                highlightbackground=LINE)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.canvas.bind("<Configure>", lambda _e: self.draw())
        pane.add(board_frame, stretch="always")

        side = tk.Frame(pane, bg="#0d1b2e", width=320, padx=12, pady=12)
        side.columnconfigure(0, weight=1)
        side.rowconfigure(8, weight=1)
        pane.add(side, minsize=260, width=320, stretch="never")

        tk.Label(side, text="LETTER RACK", bg="#0d1b2e", fg=YELLOW,
                 font=("Segoe UI", 13, "bold")).grid(row=0, column=0, sticky="w")
        tk.Label(side, textvariable=self.rack_text, bg="#07111f", fg=WHITE,
                 font=("Consolas", 17, "bold"), anchor="w", justify="left",
                 wraplength=285, padx=8, pady=10).grid(row=1, column=0, sticky="ew", pady=(5, 10))

        tk.Label(side, text="CURRENT WORD", bg="#0d1b2e", fg=CYAN,
                 font=("Segoe UI", 13, "bold")).grid(row=2, column=0, sticky="w")
        tk.Label(side, textvariable=self.word_text, bg="#07111f", fg=CYAN,
                 font=("Consolas", 20, "bold"), anchor="w", padx=8,
                 pady=10).grid(row=3, column=0, sticky="ew", pady=(5, 8))

        buttons = tk.Frame(side, bg="#0d1b2e")
        buttons.grid(row=4, column=0, sticky="ew")
        for col in range(3): buttons.columnconfigure(col, weight=1)
        tk.Button(buttons, text="Shuffle", command=self.shuffle_rack).grid(row=0, column=0, sticky="ew", padx=2)
        tk.Button(buttons, text="Clear", command=self.clear_word).grid(row=0, column=1, sticky="ew", padx=2)
        tk.Button(buttons, text="Submit", command=self.submit_word).grid(row=0, column=2, sticky="ew", padx=2)

        tk.Label(side, text="Click rack letters to build a word", bg="#0d1b2e", fg="#cbd5e1",
                 font=("Segoe UI", 9)).grid(row=5, column=0, sticky="w", pady=(8, 2))
        self.rack_list = tk.Listbox(side, height=6, bg="#07111f", fg=WHITE,
                                    selectbackground="#2563eb", font=("Consolas", 12))
        self.rack_list.grid(row=6, column=0, sticky="ew")
        self.rack_list.bind("<Double-Button-1>", self.add_selected_letter)

        tk.Label(side, textvariable=self.message_text, bg="#0d1b2e", fg="#fbbf24",
                 wraplength=285, justify="left", anchor="w").grid(row=7, column=0, sticky="ew", pady=10)

        help_text = (
            "CONTROLS\n"
            "A / Left Arrow: left flipper\n"
            "D / Right Arrow: right flipper\n"
            "Space: launch ball\n"
            "P: pause\n\n"
            "Hit the rounded letter bumpers to collect letters. Double-click letters in the rack, "
            "then Submit a word. Longer and rarer-letter words score more."
        )
        tk.Label(side, text=help_text, bg="#07111f", fg="#cbd5e1", justify="left",
                 wraplength=285, padx=10, pady=10).grid(row=8, column=0, sticky="nsew")

    def bind_keys(self):
        self.root.bind("<KeyPress-a>", lambda _e: self.set_flipper("left", True))
        self.root.bind("<KeyRelease-a>", lambda _e: self.set_flipper("left", False))
        self.root.bind("<KeyPress-d>", lambda _e: self.set_flipper("right", True))
        self.root.bind("<KeyRelease-d>", lambda _e: self.set_flipper("right", False))
        self.root.bind("<KeyPress-Left>", lambda _e: self.set_flipper("left", True))
        self.root.bind("<KeyRelease-Left>", lambda _e: self.set_flipper("left", False))
        self.root.bind("<KeyPress-Right>", lambda _e: self.set_flipper("right", True))
        self.root.bind("<KeyRelease-Right>", lambda _e: self.set_flipper("right", False))
        self.root.bind("<space>", lambda _e: self.launch())
        self.root.bind("<KeyPress-p>", lambda _e: self.toggle_pause())
        self.root.bind("<Return>", lambda _e: self.submit_word())

    def new_game(self):
        self.score = 0
        self.lives = 3
        self.multiplier = 1
        self.rack.clear()
        self.word = ""
        self.running = False
        self.paused = False
        self.ball = Ball(WIDTH - 55, HEIGHT - 100, 0, 0, False)
        self.in_launch_lane = True
        positions = [
            (155, 180), (380, 145), (605, 180),
            (250, 315), (510, 315),
            (145, 455), (380, 430), (615, 455),
            (270, 575), (490, 575)
        ]
        self.bumpers = [Bumper(x, y, 30, random.choice(LETTER_WEIGHTS)) for x, y in positions]
        # Carefully spaced ramps and rebound posts. These guide the ball without
        # sealing off lanes or creating rectangular collision traps.
        self.ramps = [
            # Short lower guides stop well before the flippers, leaving wide
            # return lanes so the ball can pass beside each flipper.
            (58, 620, 166, 684),
            (WIDTH-58, 620, WIDTH-166, 684),
            # Upper guide ramps.
            (105, 250, 190, 210),
            (WIDTH-105, 250, WIDTH-190, 210),
        ]
        # Full-height shooter ramp on the right. The ball travels to the top,
        # curves left into the playfield, and only then becomes free.
        self.launch_walls = [
            (WIDTH-92, HEIGHT-32, WIDTH-92, 118),
            (WIDTH-24, HEIGHT-32, WIDTH-24, 90),
            (WIDTH-24, 90, WIDTH-74, 48),
            (WIDTH-74, 48, WIDTH-155, 48),
        ]
        self.posts = [
            (215, 735, 18), (WIDTH-215, 735, 18),
            (315, 625, 16), (WIDTH-315, 625, 16),
            (95, 520, 15), (WIDTH-95, 520, 15),
        ]
        self.stars = [(random.randrange(30, WIDTH-30), random.randrange(40, HEIGHT-80), random.choice((1,1,1,2))) for _ in range(55)]
        self.message_text.set("Press Space or Launch to begin.")
        self.refresh_ui()
        self.draw()

    def set_flipper(self, side, down):
        if side == "left": self.left_down = down
        else: self.right_down = down

    def toggle_pause(self):
        self.paused = not self.paused
        self.message_text.set("Paused." if self.paused else "Game resumed.")

    def launch(self):
        if self.lives <= 0:
            self.new_game()
        if self.ball and not self.ball.active:
            self.ball.x, self.ball.y = WIDTH - 56, HEIGHT - 78
            self.ball.vx = 0.0
            self.ball.vy = -19.5
            self.in_launch_lane = True
            self.ball.active = True
            self.running = True
            self.message_text.set("Ball launched to the top of the shooter ramp!")

    def loop(self):
        if not self.paused:
            self.update_physics()
        self.draw()
        self.root.after(FPS_MS, self.loop)

    def update_physics(self):
        ball = self.ball
        if not ball or not ball.active:
            return
        ball.vy += 0.22
        speed = math.hypot(ball.vx, ball.vy)
        if speed > 17:
            ball.vx *= 17 / speed
            ball.vy *= 17 / speed
        ball.x += ball.vx
        ball.y += ball.vy

        left, right, top = 25, WIDTH - 25, 30
        if ball.x - BALL_RADIUS < left:
            ball.x = left + BALL_RADIUS; ball.vx = abs(ball.vx) * .92
        if ball.x + BALL_RADIUS > right:
            ball.x = right - BALL_RADIUS; ball.vx = -abs(ball.vx) * .92
        if ball.y - BALL_RADIUS < top:
            ball.y = top + BALL_RADIUS; ball.vy = abs(ball.vy) * .92

        if self.in_launch_lane:
            # Keep the ball centered and maintain enough upward energy to reach
            # the complete shooter ramp, regardless of gravity.
            lane_x = WIDTH - 56
            ball.vx += (lane_x - ball.x) * 0.10
            if ball.y > 105:
                ball.vy = min(ball.vy, -15.5)
            # At the top, send the ball left through the curved exit.
            if ball.y <= 68:
                ball.y = 68
                ball.vx = -10.5
                ball.vy = 1.5
            if ball.x < WIDTH - 112:
                self.in_launch_lane = False

        for x1, y1, x2, y2 in self.launch_walls:
            self.collide_segment(ball, x1, y1, x2, y2, 0.98)

        # Closed bottom floor with one centered drain opening. The ball rebounds
        # from the left and right floor shelves and can be lost only through the
        # gap between DRAIN_LEFT and DRAIN_RIGHT.
        self.collide_segment(ball, 25, FLOOR_Y, DRAIN_LEFT, FLOOR_Y, 0.82)
        self.collide_segment(ball, DRAIN_RIGHT, FLOOR_Y, WIDTH - 25, FLOOR_Y, 0.82)
        self.collide_segment(ball, DRAIN_LEFT, FLOOR_Y, DRAIN_LEFT, FLOOR_Y + 28, 0.86)
        self.collide_segment(ball, DRAIN_RIGHT, FLOOR_Y, DRAIN_RIGHT, FLOOR_Y + 28, 0.86)

        # Rounded letter bumpers produce a predictable radial rebound. A short
        # cooldown prevents a resting ball from rapidly collecting letters.
        for bumper in self.bumpers:
            if bumper.cooldown > 0:
                bumper.cooldown -= 1
            dx, dy = ball.x - bumper.x, ball.y - bumper.y
            distance = math.hypot(dx, dy)
            minimum = BALL_RADIUS + bumper.radius
            if 0 < distance < minimum:
                nx, ny = dx / distance, dy / distance
                ball.x = bumper.x + nx * minimum
                ball.y = bumper.y + ny * minimum
                incoming = ball.vx * nx + ball.vy * ny
                rebound = max(8.0, abs(incoming) + 4.0)
                ball.vx = nx * rebound
                ball.vy = ny * rebound
                if bumper.cooldown == 0:
                    bumper.cooldown = 20
                    self.hit_bumper(bumper)

        # Sloped ramps guide the ball toward playable lanes.
        for x1, y1, x2, y2 in self.ramps:
            self.collide_segment(ball, x1, y1, x2, y2, 1.02)

        # Circular rebound posts replace box-shaped blocks.
        for px, py, radius in self.posts:
            dx, dy = ball.x - px, ball.y - py
            distance = math.hypot(dx, dy)
            minimum = BALL_RADIUS + radius
            if 0 < distance < minimum:
                nx, ny = dx / distance, dy / distance
                ball.x = px + nx * minimum
                ball.y = py + ny * minimum
                incoming = ball.vx * nx + ball.vy * ny
                boost = max(7.0, abs(incoming) + 2.5)
                ball.vx = nx * boost
                ball.vy = ny * boost
                self.score += 10

        # Multiplier gates remain pass-through sensors.
        for tx, ty, bonus in ((330, 675, 2), (430, 675, 3)):
            if math.hypot(ball.x-tx, ball.y-ty) < BALL_RADIUS + 19:
                if self.multiplier < bonus:
                    self.multiplier = bonus
                    self.score += 100*bonus
                    self.message_text.set(f"Word multiplier increased to x{self.multiplier}!")
                    self.refresh_ui()

        self.flipper_collision(ball, left=True)
        self.flipper_collision(ball, left=False)

        # A life is lost only after the ball passes completely through the
        # centered drain. No side or full-width fall-through is allowed.
        through_center = DRAIN_LEFT < ball.x < DRAIN_RIGHT
        if through_center and ball.y - BALL_RADIUS > HEIGHT:
            ball.active = False
            self.in_launch_lane = True
            self.lives -= 1
            self.multiplier = max(1, self.multiplier - 1)
            if self.lives <= 0:
                self.high_score = max(self.high_score, self.score)
                self.message_text.set(f"Game over. Final score: {self.score}. Press Launch for a new game.")
            else:
                self.message_text.set(f"Center drain! {self.lives} ball(s) remaining. Press Launch.")
            self.refresh_ui()
        elif not through_center and ball.y + BALL_RADIUS > FLOOR_Y:
            ball.y = FLOOR_Y - BALL_RADIUS
            ball.vy = -abs(ball.vy) * 0.82

    def flipper_points(self, left):
        if left:
            pivot=(245, 815); angle = -32 if self.left_down else 16
            length=92
        else:
            pivot=(WIDTH-245, 815); angle = 212 if self.right_down else 164
            length=92
        rad=math.radians(angle)
        return pivot[0],pivot[1],pivot[0]+math.cos(rad)*length,pivot[1]+math.sin(rad)*length

    def flipper_collision(self, ball, left):
        x1,y1,x2,y2=self.flipper_points(left)
        px,py=self.nearest_on_segment(ball.x,ball.y,x1,y1,x2,y2)
        dx,dy=ball.x-px,ball.y-py
        d=math.hypot(dx,dy)
        if 0 < d < BALL_RADIUS+12:
            nx,ny=dx/d,dy/d
            ball.x=px+nx*(BALL_RADIUS+12)
            ball.y=py+ny*(BALL_RADIUS+12)
            active=self.left_down if left else self.right_down
            boost=15 if active else 10
            side_boost = -3 if left else 3
            ball.vx=nx*boost+side_boost
            ball.vy=min(-8,ny*boost-5)
            self.score += 5

    def collide_segment(self, ball, x1,y1,x2,y2, bounce):
        px,py=self.nearest_on_segment(ball.x,ball.y,x1,y1,x2,y2)
        dx,dy=ball.x-px,ball.y-py; d=math.hypot(dx,dy)
        if 0 < d < BALL_RADIUS+5:
            nx,ny=dx/d,dy/d
            ball.x=px+nx*(BALL_RADIUS+5); ball.y=py+ny*(BALL_RADIUS+5)
            dot=ball.vx*nx+ball.vy*ny
            if dot < 0:
                ball.vx=(ball.vx-2*dot*nx)*bounce
                ball.vy=(ball.vy-2*dot*ny)*bounce

    @staticmethod
    def nearest_on_segment(px,py,x1,y1,x2,y2):
        dx,dy=x2-x1,y2-y1
        den=dx*dx+dy*dy
        t=0 if den==0 else max(0,min(1,((px-x1)*dx+(py-y1)*dy)/den))
        return x1+t*dx,y1+t*dy

    def hit_bumper(self, bumper):
        bumper.flash = 10
        self.score += 25 * self.multiplier
        if len(self.rack) < MAX_RACK:
            self.rack.append(bumper.letter)
            bumper.letter = random.choice(LETTER_WEIGHTS)
            self.message_text.set(f"Collected {self.rack[-1]}! Double-click rack letters to build a word.")
        else:
            self.score += 75 * self.multiplier
            self.message_text.set("Rack full: bumper converted to bonus points.")
        self.refresh_ui()

    def refresh_ui(self):
        self.score_text.set(f"SCORE {self.score:07d}  HIGH {self.high_score:07d}")
        self.lives_text.set(f"BALLS {self.lives}")
        self.multiplier_text.set(f"WORD x{self.multiplier}")
        self.rack_text.set("  ".join(self.rack) if self.rack else "(empty)")
        self.word_text.set(self.word or "_")
        self.rack_list.delete(0, "end")
        for index, letter in enumerate(self.rack):
            self.rack_list.insert("end", f"{index+1:02d}. {letter}   ({LETTER_VALUE[letter]} point)")

    def add_selected_letter(self, _event=None):
        selection=self.rack_list.curselection()
        if not selection: return
        index=selection[0]
        if index < len(self.rack):
            self.word += self.rack.pop(index)
            self.refresh_ui()

    def clear_word(self):
        self.rack.extend(self.word)
        self.word=""
        self.refresh_ui()

    def shuffle_rack(self):
        random.shuffle(self.rack)
        self.refresh_ui()

    def submit_word(self):
        word=self.word.upper()
        if len(word) < 3:
            self.message_text.set("Words must contain at least three letters.")
            return
        if word not in COMMON_WORDS:
            self.message_text.set(f"{word} is not in this starter dictionary. Letters returned.")
            self.clear_word()
            return
        base=sum(LETTER_VALUE[ch] for ch in word)
        length_bonus=max(0,len(word)-3)*25
        earned=(base*20+length_bonus)*self.multiplier
        self.score += earned
        self.word=""
        self.multiplier=min(5,self.multiplier+1)
        self.message_text.set(f"Accepted {word}: +{earned} points. Multiplier is now x{self.multiplier}.")
        self.refresh_ui()

    def board_transform(self):
        w=max(1,self.canvas.winfo_width()); h=max(1,self.canvas.winfo_height())
        scale=min(w/WIDTH,h/HEIGHT)
        ox=(w-WIDTH*scale)/2; oy=(h-HEIGHT*scale)/2
        return scale,ox,oy

    def draw(self):
        self.canvas.delete("all")
        s,ox,oy=self.board_transform()
        def X(v): return ox+v*s
        def Y(v): return oy+v*s
        def line(points, **kw): self.canvas.create_line(*[z for p in points for z in (X(p[0]),Y(p[1]))], **kw)

        self.canvas.create_rectangle(X(20),Y(25),X(WIDTH-20),Y(HEIGHT-5),fill=BOARD,outline=LINE,width=max(2,int(3*s)))
        for x,y,r in self.stars:
            self.canvas.create_oval(X(x-r),Y(y-r),X(x+r),Y(y+r),fill="#334155",outline="")
        # Physical ramps align exactly with the collision segments.
        for x1, y1, x2, y2 in self.ramps:
            line([(x1,y1),(x2,y2)],fill=PURPLE,width=max(4,int(10*s)),capstyle=tk.ROUND)
            line([(x1,y1),(x2,y2)],fill="#ddd6fe",width=max(1,int(2*s)),capstyle=tk.ROUND)
        # Rounded posts replace collision blocks.
        for px, py, radius in self.posts:
            self.canvas.create_oval(X(px-radius),Y(py-radius),X(px+radius),Y(py+radius),fill="#1e293b",outline=YELLOW,width=max(2,int(3*s)))

        self.canvas.create_text(X(WIDTH/2),Y(62),text="WRITERS JUMBLER",fill=WHITE,font=("Segoe UI",max(10,int(24*s)),"bold"))
        self.canvas.create_text(X(WIDTH/2),Y(92),text="LETTER PINBALL",fill=YELLOW,font=("Consolas",max(8,int(15*s)),"bold"))

        for bumper in self.bumpers:
            color=WHITE if bumper.flash>0 else CYAN
            if bumper.flash>0: bumper.flash-=1
            self.canvas.create_oval(X(bumper.x-bumper.radius),Y(bumper.y-bumper.radius),X(bumper.x+bumper.radius),Y(bumper.y+bumper.radius),fill="#172554",outline=color,width=max(2,int(4*s)))
            self.canvas.create_text(X(bumper.x),Y(bumper.y),text=bumper.letter,fill=WHITE,font=("Times New Roman",max(10,int(23*s)),"bold"))

        for tx,ty,bonus in ((330,675,2),(430,675,3)):
            self.canvas.create_oval(X(tx-21),Y(ty-21),X(tx+21),Y(ty+21),fill="",outline=YELLOW,width=max(2,int(3*s)))
            self.canvas.create_text(X(tx),Y(ty),text=f"x{bonus}",fill=WHITE,font=("Segoe UI",max(8,int(12*s)),"bold"))

        # Bottom floor shelves close the table everywhere except the center gap.
        line([(25,FLOOR_Y),(DRAIN_LEFT,FLOOR_Y)],fill=RED,width=max(4,int(9*s)),capstyle=tk.ROUND)
        line([(DRAIN_RIGHT,FLOOR_Y),(WIDTH-25,FLOOR_Y)],fill=RED,width=max(4,int(9*s)),capstyle=tk.ROUND)
        line([(DRAIN_LEFT,FLOOR_Y),(DRAIN_LEFT,FLOOR_Y+28)],fill=RED,width=max(3,int(7*s)))
        line([(DRAIN_RIGHT,FLOOR_Y),(DRAIN_RIGHT,FLOOR_Y+28)],fill=RED,width=max(3,int(7*s)))
        self.canvas.create_text(X((DRAIN_LEFT+DRAIN_RIGHT)/2),Y(FLOOR_Y+18),text="DRAIN",fill=RED,font=("Consolas",max(7,int(10*s)),"bold"))

        for left in (True,False):
            x1,y1,x2,y2=self.flipper_points(left)
            line([(x1,y1),(x2,y2)],fill=YELLOW,width=max(5,int(17*s)),capstyle=tk.ROUND)
            self.canvas.create_oval(X(x1-13),Y(y1-13),X(x1+13),Y(y1+13),fill=RED,outline=WHITE)

        # Full-height shooter ramp. Both visible walls use the exact segments
        # used by collision detection.
        for x1, y1, x2, y2 in self.launch_walls:
            line([(x1,y1),(x2,y2)],fill="#475569",width=max(3,int(6*s)),capstyle=tk.ROUND)
            line([(x1,y1),(x2,y2)],fill=CYAN,width=max(1,int(2*s)),capstyle=tk.ROUND)
        self.canvas.create_text(X(WIDTH-56),Y(770),text="FULL RAMP LAUNCH",angle=90,fill="#cbd5e1",font=("Consolas",max(8,int(10*s)),"bold"))

        if self.ball and self.ball.active:
            b=self.ball
            self.canvas.create_oval(X(b.x-BALL_RADIUS),Y(b.y-BALL_RADIUS),X(b.x+BALL_RADIUS),Y(b.y+BALL_RADIUS),fill=WHITE,outline=CYAN,width=max(1,int(2*s)))
        elif self.ball and self.lives>0:
            self.canvas.create_oval(X(self.ball.x-BALL_RADIUS),Y(self.ball.y-BALL_RADIUS),X(self.ball.x+BALL_RADIUS),Y(self.ball.y+BALL_RADIUS),fill=WHITE,outline=CYAN)


def main():
    root=tk.Tk()
    WritersJumblerPinball(root)
    root.mainloop()


if __name__ == "__main__":
    main()
