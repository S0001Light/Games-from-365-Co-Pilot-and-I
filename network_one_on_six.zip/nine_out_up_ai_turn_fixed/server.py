import argparse,json,random,socketserver,string,threading
from common import deck24,card,best_from_ten,HAND_NAMES
rooms={};lock=threading.RLock()
def room_code():
    while True:
        x=''.join(random.choice(string.ascii_uppercase+string.digits) for _ in range(6))
        if x not in rooms:return x
def send(h,m):h.request.sendall((json.dumps(m)+'\n').encode())

class Room:
 def __init__(self,code):
  self.code=code;self.players={};self.clients={};self.bots=set();self.chips={};self.private={};self.backs={};self.table=[];self.folded=set();self.deck=[];self.pot=0;self.bets={};self.current_bet=0;self.turn=None;self.dealer=-1;self.street='lobby';self.started=False;self.acted=set();self.stage=0;self.discarded=set()
 def active(self):return [p for p in sorted(self.players) if p not in self.folded and self.chips.get(p,0)>0]
 def public(self,viewer):
  show=self.street=='showdown';private={}
  for p,c in self.private.items():private[str(p)]=c if p==viewer or show else None
  return {'type':'state','code':self.code,'players':self.players,'bots':sorted(self.bots),'chips':self.chips,'private':private,'backs':self.backs,'table':self.table,'folded':sorted(self.folded),'pot':self.pot,'bets':self.bets,'current_bet':self.current_bet,'turn':self.turn,'dealer':self.dealer,'street':self.street,'stage':self.stage,'discarded':sorted(self.discarded),'can_discard':self.stage==3,'started':self.started}
 def states(self):
  for p,h in list(self.clients.items()):
   try:send(h,self.public(p))
   except OSError:self.clients.pop(p,None)
 def broadcast(self,m):
  for h in list(self.clients.values()):
   try:send(h,m)
   except OSError:pass
 def next_active(self,p):
  a=self.active();return next((x for x in a if x>p),a[0]) if a else None
 def pay(self,p,n):
  n=min(n,self.chips[p]);self.chips[p]-=n;self.bets[p]+=n;self.pot+=n
 def begin(self):
  if len(self.players)<2:return False
  self.deck=deck24();random.shuffle(self.deck);self.table=[];self.private={};self.backs={};self.folded=set();self.bets={p:0 for p in self.players};self.pot=0;self.current_bet=0;self.acted=set();self.discarded=set();self.stage=0;self.dealer=(self.dealer+1)%len(self.players);self.street='shuffle';self.started=True
  for p in self.players:self.backs[str(p)]=random.randint(1,2)
  self.broadcast({'type':'shuffle','backs':[random.randint(1,2) for _ in range(24)]})
  threading.Timer(3.2,self.deal).start();return True
 def deal(self):
  with lock:
   if self.street!='shuffle':return
   # One private card per player, then the first three shared table cards.
   for p in sorted(self.players):self.private[p]=self.deck.pop().wire()
   self.table=[self.deck.pop().wire() for _ in range(3)]
   self.stage=3;self.street='table 3';self.start_betting()
 def start_betting(self):
  self.bets={p:0 for p in self.players};self.current_bet=0;self.acted=set();self.turn=self.next_active(self.dealer);self.states();self.schedule_bot()
 def next_table_stage(self):
  if self.stage < 6:
   self.table.append(self.deck.pop().wire());self.stage+=1;self.street=f'table {self.stage}';self.start_betting()
  else:self.showdown()
 def schedule_bot(self):
  if self.turn in self.bots and self.started and self.stage in (3,4,5,6):
   t=threading.Timer(.20,self.bot,args=(self.turn,));t.daemon=True;t.start()
 def strength(self,p):
  cards=[card(x) for x in self.table+[self.private[p]]]
  if len(cards)>=5:return best_from_ten(cards)[0]
  values=[c.value for c in cards]
  return 1 if len(values)!=len(set(values)) else 0
 def bot(self,p):
  with lock:
   if self.turn!=p or p not in self.bots or p in self.folded:return
   need=max(0,self.current_bet-self.bets[p]);v=self.strength(p)
   private=card(self.private[p])
   table_ranks={card(x).rank for x in self.table}
   if self.stage==3 and p not in self.discarded and private.rank not in table_ranks and private.value<=11 and random.random()<.60:
    action='discard'
   else:
    action='fold' if need and v<1 and random.random()<.35 else ('raise' if v>=2 and random.random()<.30 else 'call')
   self.action(p,action)
 def action(self,p,a):
  if self.turn!=p:return
  if a=='discard':
   if self.stage!=3 or p in self.discarded:return
   self.private[p]=self.deck.pop().wire();self.discarded.add(p)
   self.broadcast({'type':'notice','text':f'{self.players[p]} discarded the private card and drew a replacement.'})
  elif a=='fold':self.folded.add(p)
  elif a=='call':self.pay(p,max(0,self.current_bet-self.bets[p]))
  elif a=='raise':
   self.pay(p,max(0,self.current_bet-self.bets[p])+25);self.current_bet=self.bets[p]
   # A raise reopens action for every other active player.
   self.acted={p}
  else:return
  if a!='raise':self.acted.add(p)
  active=self.active()
  if len(active)==1:
   w=active[0];self.chips[w]+=self.pot;self.broadcast({'type':'notice','text':f'{self.players[w]} wins; all others folded.'});self.pot=0;self.street='showdown';self.started=False;self.turn=None;self.states();return
  # Betting round only closes when all active players have acted AND all
  # remaining players have matched the current bet.
  settled=[x for x in active if x in self.acted and self.bets[x]>=self.current_bet]
  if len(settled)==len(active):
   self.turn=None;self.states();self.next_table_stage();return
  nxt=self.next_active(p);guard=0
  while (nxt in self.acted and self.bets[nxt]>=self.current_bet) and guard<10:
   nxt=self.next_active(nxt);guard+=1
  self.turn=nxt;self.states();self.schedule_bot()
 def showdown(self):
  active=self.active();ranked={p:best_from_ten([card(x) for x in self.table+[self.private[p]]]) for p in active};best=max(ranked.values());wins=[p for p,v in ranked.items() if v==best];share=self.pot//len(wins) if wins else 0
  for p in wins:self.chips[p]+=share
  self.broadcast({'type':'notice','text':f"Showdown: {', '.join(self.players[p] for p in wins)} win with {HAND_NAMES[best[0]]}."});self.pot=0;self.street='showdown';self.started=False;self.turn=None;self.states()

class Handler(socketserver.StreamRequestHandler):
 def handle(self):
  self.r=None;self.p=None
  while True:
   line=self.rfile.readline()
   if not line:break
   try:
    with lock:self.process(json.loads(line))
   except Exception as e:
    try:send(self,{'type':'error','message':str(e)})
    except:break
 def process(self,m):
  t=m.get('type')
  if t=='create':
   r=Room(room_code());rooms[r.code]=r;return self.join(r,m.get('name','Player'))
  if t=='join':
   r=rooms.get(str(m.get('code','')).upper())
   if not r:return send(self,{'type':'error','message':'Room not found.'})
   if r.started:return send(self,{'type':'error','message':'Hand in progress. Join after showdown.'})
   return self.join(r,m.get('name','Player'))
  if not self.r:return
  if t=='add_bot':
   p=next((x for x in range(4) if x not in self.r.players),None)
   if p is None:return send(self,{'type':'error','message':'Room full.'})
   self.r.players[p]=f'AI Player {p+1}';self.r.bots.add(p);self.r.chips[p]=500;self.r.states()
  elif t=='start':
   if not self.r.begin():send(self,{'type':'error','message':'Add at least one opponent.'})
  elif t=='action':self.r.action(self.p,m.get('action'))
  elif t=='chat':
   text=str(m.get('text','')).strip()[:250]
   if text:self.r.broadcast({'type':'chat','name':self.r.players[self.p],'text':text})
 def join(self,r,name):
  p=next((x for x in range(4) if x not in r.players),None)
  if p is None:return send(self,{'type':'error','message':'Room full.'})
  self.r=r;self.p=p;r.players[p]=str(name)[:20] or 'Player';r.clients[p]=self;r.chips[p]=500;send(self,{'type':'joined','code':r.code,'player':p});r.states()
 def finish(self):
  with lock:
   if self.r and self.p is not None:self.r.clients.pop(self.p,None)
class Server(socketserver.ThreadingTCPServer):allow_reuse_address=True;daemon_threads=True
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--host',default='0.0.0.0');ap.add_argument('--port',type=int,default=5052);a=ap.parse_args()
 with Server((a.host,a.port),Handler) as s:print(f'Nine Out Up server on {a.host}:{a.port}');s.serve_forever()
