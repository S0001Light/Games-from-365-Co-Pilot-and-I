NINE OUT UP - SIX SHARED CARDS + FIRST-ROUND DISCARD

DEAL ORDER
  1. Each player receives one private card.
  2. Three shared cards are revealed.
  3. During this first betting round, each player may click Discard / Draw once.
     The private card is replaced with the next card from the deck.
     The discarded card stays out of play and is not shown to other players.
  4. Shared card 4 is revealed, followed by betting.
  5. Shared card 5 is revealed, followed by betting.
  6. Shared card 6 is revealed, followed by final betting and showdown.

Discard / Draw counts as that player's action for the first round. A player may
instead Fold, Check / Call, or Raise 25. AI players may also discard a weak
private card during the first round.

Each result uses the strongest five-card poker hand from six shared cards plus
one private card. Valid straights are 9-10-J-Q-K and 10-J-Q-K-A.

NETWORK
  python server.py
  python client.py
  Default port: 5052

Includes rooms, chat, human and AI players, Joker backs, spinning left-to-right
shuffle, no burn cards, and no turn timeout.

AI TURN FORWARD FIX
  - Fixed AI turns after Check / Call, Raise, Fold, or Discard / Draw.
  - Table stages are named table 3, table 4, table 5, and table 6; AI scheduling
    now recognizes those stages instead of incorrectly waiting for a street
    named betting.
  - When the current turn belongs to an AI player, the server automatically
    schedules the AI action and then advances to the next player.
  - A raise still reopens action for other active players.
