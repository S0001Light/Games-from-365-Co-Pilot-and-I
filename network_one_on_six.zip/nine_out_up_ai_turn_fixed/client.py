import json,math,queue,socket,threading,time,tkinter as tk
from pathlib import Path
from tkinter import messagebox
from common import SYMBOL
BG='#07111f';FELT='#075c3b';PANEL='#0d1b2e';WHITE='#fff';GOLD='#facc15';RED='#ef4444';CYAN='#22d3ee'
class App:
 def __init__(self,root):
  self.root=root;root.title('Nine Out Up');root.geometry('1250x850');root.minsize(900,650);root.configure(bg=BG);root.rowconfigure(1,weight=1);root.columnconfigure(0,weight=1)
  self.sock=None;self.q=queue.Queue();self.pid=None;self.state=None;self.anim=None;self.images={};self.load_backs()
  top=tk.Frame(root,bg=PANEL,padx=7,pady=7);top.grid(row=0,column=0,sticky='ew');top.columnconfigure(10,weight=1)
  self.host=tk.Entry(top,width=14);self.host.insert(0,'127.0.0.1');self.host.grid(row=0,column=0);self.port=tk.Entry(top,width=6);self.port.insert(0,'5052');self.port.grid(row=0,column=1);self.name=tk.Entry(top,width=12);self.name.insert(0,'Player');self.name.grid(row=0,column=2)
  tk.Button(top,text='Connect',command=self.connect).grid(row=0,column=3);tk.Button(top,text='Create',command=lambda:self.send({'type':'create','name':self.name.get()})).grid(row=0,column=4);self.code=tk.Entry(top,width=8);self.code.grid(row=0,column=5);tk.Button(top,text='Join',command=lambda:self.send({'type':'join','code':self.code.get(),'name':self.name.get()})).grid(row=0,column=6);tk.Button(top,text='Add AI',command=lambda:self.send({'type':'add_bot'})).grid(row=0,column=7);tk.Button(top,text='Start',command=lambda:self.send({'type':'start'})).grid(row=0,column=8)
  self.status=tk.StringVar(value='Connect');tk.Label(top,textvariable=self.status,bg=PANEL,fg=WHITE).grid(row=0,column=10,sticky='e')
  pane=tk.PanedWindow(root,orient='horizontal',sashwidth=6,bg=BG);pane.grid(row=1,column=0,sticky='nsew',padx=8,pady=8);f=tk.Frame(pane,bg=BG);f.rowconfigure(0,weight=1);f.columnconfigure(0,weight=1);self.c=tk.Canvas(f,bg=FELT,highlightthickness=0);self.c.grid(sticky='nsew');self.c.bind('<Configure>',lambda e:self.draw());pane.add(f,stretch='always')
  side=tk.Frame(pane,bg=PANEL,width=280,padx=8,pady=8);side.rowconfigure(2,weight=1);side.columnconfigure(0,weight=1);pane.add(side,minsize=240,width=280);self.list=tk.Listbox(side,height=8,bg=BG,fg=WHITE);self.list.grid(row=0,column=0,sticky='ew');self.chat=tk.Text(side,state='disabled',bg=BG,fg=WHITE);self.chat.grid(row=2,column=0,sticky='nsew',pady=8);self.entry=tk.Entry(side);self.entry.grid(row=3,column=0,sticky='ew');self.entry.bind('<Return>',self.chat_send)
  bar=tk.Frame(root,bg=PANEL,padx=8,pady=8);bar.grid(row=2,column=0,sticky='ew');self.buttons=[]
  for text,a in [('Discard / Draw','discard'),('Fold','fold'),('Check / Call','call'),('Raise 25','raise')]:
   b=tk.Button(bar,text=text,width=12,state='disabled',command=lambda x=a:self.send({'type':'action','action':x}));b.pack(side='left',padx=4);self.buttons.append(b)
  root.after(40,self.poll);root.after(16,self.animate)
 def load_backs(self):
  base=Path(__file__).parent
  for n in (1,2):
   for p in (base/f'JKR{n}.gif',base/'assets'/f'JKR{n}.gif'):
    if p.exists():
     try:self.images[n]=tk.PhotoImage(file=str(p));break
     except:pass
 def connect(self):
  try:self.sock=socket.create_connection((self.host.get().strip(),int(self.port.get())),5);self.sock.settimeout(None);threading.Thread(target=self.read,daemon=True).start();self.status.set('Connected - no timeout')
  except Exception as e:messagebox.showerror('Connect',str(e))
 def read(self):
  try:
   for line in self.sock.makefile('r',encoding='utf8'):self.q.put(json.loads(line))
  except Exception as e:self.q.put({'type':'error','message':str(e)})
 def send(self,m):
  if self.sock:self.sock.sendall((json.dumps(m)+'\n').encode())
 def poll(self):
  while True:
   try:self.handle(self.q.get_nowait())
   except queue.Empty:break
  self.root.after(40,self.poll)
 def handle(self,m):
  t=m.get('type')
  if t=='joined':self.pid=m['player'];self.code.delete(0,'end');self.code.insert(0,m['code'])
  elif t=='state':self.state=m;self.refresh();self.draw()
  elif t=='shuffle':self.anim={'start':time.time(),'backs':m['backs']}
  elif t=='chat':self.log(f"{m['name']}: {m['text']}")
  elif t=='notice':self.log(m['text'])
  elif t=='error':self.log('ERROR: '+m['message'])
 def refresh(self):
  s=self.state
  if not s:return
  self.status.set(f"Room {s['code']} | Shared cards {s.get('stage',0)}/6 | Pot {s['pot']} | No timer")
  self.list.delete(0,'end')
  for k,n in sorted(s['players'].items(),key=lambda x:int(x[0])):
   p=int(k);f=[]
   if p==self.pid:f.append('YOU')
   if p in s.get('bots',[]):f.append('AI')
   if p==s['turn']:f.append('TURN')
   if p in s['folded']:f.append('FOLD')
   self.list.insert('end',f"{n}: {s['chips'].get(k,s['chips'].get(p,0))} {' '.join(f)}")
  my_turn=s['turn']==self.pid
  for i,b in enumerate(self.buttons):
   enabled=my_turn
   if i==0:
    enabled=my_turn and s.get('can_discard',False) and self.pid not in s.get('discarded',[])
   b.config(state='normal' if enabled else 'disabled')
 def log(self,t):self.chat.config(state='normal');self.chat.insert('end',t+'\n');self.chat.see('end');self.chat.config(state='disabled')
 def chat_send(self,e=None):
  t=self.entry.get().strip()
  if t:self.send({'type':'chat','text':t});self.entry.delete(0,'end')
 def card(self,x,y,wire=None,hidden=False,back=1,scale=1,spin=1):
  w=max(3,58*scale*abs(spin));h=82*scale;self.c.create_rectangle(x-w/2,y-h/2,x+w/2,y+h/2,fill='white' if not hidden else '#172554',outline=GOLD,width=2)
  if abs(spin)<.18:return
  if hidden:
   img=self.images.get(back)
   if img and abs(spin)>.84:self.c.create_image(x,y,image=img)
   else:self.c.create_text(x,y,text=f'JOKER\n{back}',fill=CYAN if back==1 else RED,font=('Segoe UI',max(7,int(12*scale*abs(spin))),'bold'))
  elif wire:
   r,s=wire[0],wire[1];self.c.create_text(x,y,text=('10' if r=='T' else r)+SYMBOL[s],fill=RED if s in 'HD' else '#111827',font=('Consolas',max(8,int(16*scale*abs(spin))),'bold'))
 def animate(self):
  if self.anim and time.time()-self.anim['start']>3:self.anim=None
  if self.anim:self.draw()
  self.root.after(16,self.animate)
 def draw(self):
  c=self.c;c.delete('all');w=max(1,c.winfo_width());h=max(1,c.winfo_height());c.create_oval(w*.07,h*.08,w*.93,h*.92,fill=FELT,outline='#d6a848',width=7)
  if self.anim:
   t=(time.time()-self.anim['start'])/3
   c.create_text(w/2,h*.14,text='NINE OUT UP - SPIN SHUFFLE',fill=WHITE,font=('Segoe UI',16,'bold'))
   for i in range(24):
    phase=(t*1.8+i/24)%1;x=-50+phase*(w+100);y=h*.25+(i%6)*h*.09;spin=math.cos((phase*4+i*.15)*math.tau);self.card(x,y,hidden=True,back=self.anim['backs'][i],scale=.72,spin=spin)
   return
  if not self.state:return
  s=self.state;pos=[(.5,.82),(.14,.53),(.5,.14),(.86,.53)]
  for k,n in sorted(s['players'].items(),key=lambda x:int(x[0])):
   p=int(k);x,y=w*pos[p][0],h*pos[p][1]
   c.create_text(x,y-59,text=n,fill=RED if p in s['folded'] else WHITE,font=('Segoe UI',10,'bold'))
   wire=s['private'].get(str(p));back=s['backs'].get(str(p),1)
   self.card(x,y,wire,hidden=wire is None,back=back,scale=.82)
  c.create_text(w/2,h*.31,text='SIX SHARED CARDS - REVEALED 3, 4, 5, 6',fill=GOLD,font=('Consolas',16,'bold'))
  table=s.get('table',[])
  for i in range(6):
   x=w/2+(i-2.5)*67
   y=h*.50
   self.card(x,y,table[i] if i<len(table) else None,hidden=i>=len(table),back=1+(i%2),scale=.78)
  c.create_text(w/2,h*.64,text=('FIRST ROUND: DISCARD YOUR PRIVATE CARD ONCE' if s.get('stage')==3 else ''),fill=GOLD,font=('Segoe UI',10,'bold'))
  c.create_text(w/2,h*.69,text=f"POT {s['pot']}",fill=CYAN,font=('Consolas',16,'bold'))
  c.create_text(w/2,h*.94,text='First round allows one private-card discard/draw • Shared cards reveal 3, 4, 5, 6 • No timer',fill='#d1fae5',font=('Segoe UI',9))

if __name__=='__main__':root=tk.Tk();App(root);root.mainloop()
