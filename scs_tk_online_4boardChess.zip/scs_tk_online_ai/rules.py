from dataclasses import dataclass, asdict

BOARD_SIZE = 16
BACK = ("rook", "knight", "bishop", "king", "queen", "bishop", "knight", "rook")

@dataclass
class Piece:
    id: int
    owner: int
    kind: str
    row: int
    col: int
    moved: bool = False
    alive: bool = True

    def dict(self): return asdict(self)


def initial_pieces():
    pieces, pid = [], 0
    def army(owner, cols, back_row, pawn_row):
        nonlocal pid
        for i, kind in enumerate(BACK):
            pieces.append(Piece(pid, owner, kind, back_row, cols[i])); pid += 1
        for col in cols:
            pieces.append(Piece(pid, owner, "pawn", pawn_row, col)); pid += 1
    army(0, list(range(8)), 0, 1)
    army(1, list(range(8, 16)), 0, 1)
    army(2, list(range(8)), 15, 14)
    army(3, list(range(8, 16)), 15, 14)
    return pieces


def at(pieces, row, col):
    return next((p for p in pieces if p.alive and p.row == row and p.col == col), None)


def clear(pieces, piece, row, col):
    sr = (row > piece.row) - (row < piece.row)
    sc = (col > piece.col) - (col < piece.col)
    r, c = piece.row + sr, piece.col + sc
    while (r, c) != (row, col):
        if at(pieces, r, c): return False
        r, c = r + sr, c + sc
    return True


def legal(pieces, piece, row, col):
    if not piece or not piece.alive or not (0 <= row < 16 and 0 <= col < 16): return False
    if (row, col) == (piece.row, piece.col): return False
    target = at(pieces, row, col)
    if target and target.owner == piece.owner: return False
    dr, dc = row - piece.row, col - piece.col
    ar, ac = abs(dr), abs(dc)
    if piece.kind == "king": return max(ar, ac) == 1
    if piece.kind == "knight": return (ar, ac) in ((1, 2), (2, 1))
    if piece.kind == "rook": return (dr == 0 or dc == 0) and clear(pieces, piece, row, col)
    if piece.kind == "bishop": return ar == ac and clear(pieces, piece, row, col)
    if piece.kind == "queen": return (dr == 0 or dc == 0 or ar == ac) and clear(pieces, piece, row, col)
    if piece.kind == "pawn":
        direction = 1 if piece.owner < 2 else -1
        advance = dr * direction
        if dc == 0 and not target:
            return 1 <= advance <= (1 if piece.moved else 5) and clear(pieces, piece, row, col)
        return advance == 1 and ac == 1 and target is not None and target.owner != piece.owner
    return False


def legal_squares(pieces, piece):
    return [[r, c] for r in range(16) for c in range(16) if legal(pieces, piece, r, c)]
