SCS ONLINE TKINTER CHESS

FILES
  server.py  - authoritative multiplayer server
  client.py  - resizable Tkinter game client with chat
  rules.py   - movement rules
  assets/    - piece images

START THE SERVER
  python server.py

START EACH CLIENT
  python client.py

LOCAL TEST
  1. Run the server once.
  2. Run client.py in 2-4 separate windows.
  3. Leave server address as 127.0.0.1 and port 5050.
  4. Click Connect.
  5. One client clicks Create Room.
  6. Other clients enter the displayed code and click Join.
  7. Click Start.

OTHER COMPUTERS ON THE SAME NETWORK
  Use the server computer's LAN IPv4 address instead of 127.0.0.1.
  Allow TCP port 5050 through the server computer's firewall.

INTERNET PLAY
  Run server.py on a reachable computer or VPS. Open/forward TCP port 5050.
  Players enter that public hostname or IP. For public deployment, place the
  raw TCP service behind an encrypted VPN/tunnel or add TLS and authentication.

RESIZING
  Resize or maximize the window. The board keeps square cells and centers itself.
  Drag the divider between the board and chat. The UI works across different
  monitor sizes and DPI settings.

AI AND PLAYER LIST
  - The right panel now lists all human and AI seats.
  - Click Add AI before starting to fill an available seat.
  - AI is server controlled. It evaluates every legal move, prioritizes captures
    by piece value, and otherwise selects among legal moves.
  - You can create a room, click Add AI, then Start for a human-vs-AI game.

10-SECOND MOVE TIMER
  - Every human and AI turn has a server-authoritative 10-second limit.
  - AI normally thinks for about one second and then performs a legal move.
  - If a human reaches zero, the server makes a legal automatic move so the game continues.
  - The client displays a synchronized countdown in the top bar.

VISIBLE AI MOVES
  - The square an AI piece moved from is outlined yellow.
  - The destination square is outlined cyan.
  - A white arrow shows the movement direction for four seconds.
  - Chat reports exact grid coordinates, for example: AI Player 2 moved knight B1 to C3.
  - Capture announcements include the captured piece type.

ANIMATED AI PIECES
  - AI and timeout moves animate the actual piece from its old square to its new square.
  - Animation lasts 0.85 seconds and uses smooth interpolation.
  - The moving piece is drawn above the board and cannot disappear behind other pieces.
  - After animation, the piece is permanently rendered on the destination square.
  - The yellow origin, cyan destination, arrow, and chat coordinate report remain visible.

PIECES ALWAYS VISIBLE AFTER MOVES
  - Every piece is now drawn as a bright player-colored disc with a permanent
    high-contrast K, Q, R, B, N, or P symbol.
  - Rendering no longer depends on PNG visibility, size, or color.
  - The player's number is printed on every piece.
  - The latest origin and destination remain outlined until another move occurs.
  - A permanent Last move panel shows the player, piece, origin, destination,
    and capture. The moved piece remains on the destination square.
