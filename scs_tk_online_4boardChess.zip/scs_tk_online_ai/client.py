import json, queue, socket, threading, tkinter as tk
from pathlib import Path
from tkinter import messagebox
from rules import Piece

COLORS=("#38BDF8","#F97316","#A78BFA","#22C55E")
DARK,LIGHT="#533CD5","#141318"
LETTERS={"king":"K","queen":"Q","rook":"R","bishop":"B","knight":"N","pawn":"P"}
FILES={"pawn":("pwnb.png","pwnb.png","pwn.png","pwn.png"),"rook":("rkb.png","rkb.png","rk.png","rk.png"),"knight":("kntb.png","kntb.png","knt.png","knt.png"),"bishop":("bpb.png","bpb.png","bp.png","bp.png"),"king":("kb.png","kb.png","k.png","k.png"),"queen":("qb.png","qb.png","q.png","q.png")}

class App:
 def __init__(self,root):
  self.root=root; root.title("SCS Online Chess"); root.minsize(760,560); root.geometry("1200x820")
  root.configure(bg="#07111F"); root.rowconfigure(1,weight=1); root.columnconfigure(0,weight=1)
  self.sock=None; self.inbox=queue.Queue(); self.state=None; self.pid=None; self.selected=None; self.moves=set(); self.images={}; self.clock_offset=0.0; self.last_move_seen=None; self.last_move_until=0.0; self.animation=None
  self.top=tk.Frame(root,bg="#0D1B2E"); self.top.grid(row=0,column=0,sticky="ew"); self.top.columnconfigure(10,weight=1)
  self.host=tk.Entry(self.top,width=16); self.host.insert(0,"127.0.0.1"); self.host.grid(row=0,column=0,padx=4,pady=8)
  self.port=tk.Entry(self.top,width=6); self.port.insert(0,"5050"); self.port.grid(row=0,column=1,padx=4)
  self.name=tk.Entry(self.top,width=12); self.name.insert(0,"Player"); self.name.grid(row=0,column=2,padx=4)
  tk.Button(self.top,text="Connect",command=self.connect).grid(row=0,column=3,padx=4)
  tk.Button(self.top,text="Create Room",command=lambda:self.send({"type":"create","name":self.name.get()})).grid(row=0,column=4,padx=4)
  self.code=tk.Entry(self.top,width=8); self.code.grid(row=0,column=5,padx=4)
  tk.Button(self.top,text="Join",command=lambda:self.send({"type":"join","code":self.code.get(),"name":self.name.get()})).grid(row=0,column=6,padx=4)
  tk.Button(self.top,text="Start",command=lambda:self.send({"type":"start"})).grid(row=0,column=7,padx=4)
  tk.Button(self.top,text="Add AI",command=lambda:self.send({"type":"add_bot"})).grid(row=0,column=8,padx=4)
  self.timer_text=tk.StringVar(value="Time: --"); tk.Label(self.top,textvariable=self.timer_text,bg="#7F1D1D",fg="white",font=("Segoe UI",12,"bold"),padx=10).grid(row=0,column=9,padx=5)
  self.status=tk.StringVar(value="Connect to a server."); tk.Label(self.top,textvariable=self.status,bg="#0D1B2E",fg="white").grid(row=0,column=10,sticky="e",padx=8)
  self.pane=tk.PanedWindow(root,orient="horizontal",sashwidth=7,bg="#07111F"); self.pane.grid(row=1,column=0,sticky="nsew",padx=8,pady=8)
  self.board_frame=tk.Frame(self.pane,bg="#07111F"); self.board_frame.rowconfigure(0,weight=1); self.board_frame.columnconfigure(0,weight=1)
  self.canvas=tk.Canvas(self.board_frame,bg="#07111F",highlightthickness=0); self.canvas.grid(sticky="nsew"); self.canvas.bind("<Button-1>",self.click); self.canvas.bind("<Configure>",lambda e:self.draw())
  self.side=tk.Frame(self.pane,bg="#0D1B2E",width=300); self.side.rowconfigure(4,weight=1); self.side.columnconfigure(0,weight=1)
  tk.Label(self.side,text="Players",font=("Segoe UI",13,"bold"),bg="#0D1B2E",fg="white").grid(row=0,column=0,sticky="w",padx=10,pady=(8,2))
  self.players=tk.Listbox(self.side,height=6,bg="#07111F",fg="white",selectbackground="#07111F"); self.players.grid(row=1,column=0,sticky="ew",padx=10,pady=(0,8))
  self.last_move_text=tk.StringVar(value="Last move: none"); tk.Label(self.side,textvariable=self.last_move_text,bg="#172554",fg="#FFFFFF",anchor="w",justify="left",wraplength=270,padx=8,pady=6).grid(row=2,column=0,sticky="ew",padx=10,pady=(0,8))
  tk.Label(self.side,text="Game Chat",font=("Segoe UI",13,"bold"),bg="#0D1B2E",fg="white").grid(row=3,column=0,sticky="w",padx=10,pady=4)
  self.chat=tk.Text(self.side,state="disabled",wrap="word",bg="#07111F",fg="white"); self.chat.grid(row=4,column=0,sticky="nsew",padx=10)
  self.chat_entry=tk.Entry(self.side); self.chat_entry.grid(row=5,column=0,sticky="ew",padx=10,pady=8); self.chat_entry.bind("<Return>",self.chat_send)
  self.pane.add(self.board_frame,stretch="always"); self.pane.add(self.side,minsize=230,width=300,stretch="never")
  self.load_images(); root.after(50,self.poll); root.after(100,self.tick_timer)
 def load_images(self):
  base=Path(__file__).parent/"assets"
  for kind,names in FILES.items():
   for owner,name in enumerate(names):
    try: self.images[(kind,owner)]=tk.PhotoImage(file=str(base/name))
    except tk.TclError: pass
 def connect(self):
  try:
   self.sock=socket.create_connection((self.host.get().strip(),int(self.port.get())),timeout=5); self.sock.settimeout(None)
   threading.Thread(target=self.reader,daemon=True).start(); self.status.set("Connected. Create or join a room.")
  except Exception as e: messagebox.showerror("Connection failed",str(e))
 def reader(self):
  try:
   f=self.sock.makefile("r",encoding="utf-8")
   for line in f: self.inbox.put(json.loads(line))
  except Exception as e: self.inbox.put({"type":"error","message":str(e)})
 def send(self,m):
  if not self.sock: return messagebox.showinfo("Not connected","Connect to the server first.")
  try: self.sock.sendall((json.dumps(m)+"\n").encode())
  except OSError as e: messagebox.showerror("Network error",str(e))
 def poll(self):
  while True:
   try: self.handle(self.inbox.get_nowait())
   except queue.Empty: break
  self.root.after(50,self.poll)
 def handle(self,m):
  t=m.get("type")
  if t=="joined": self.pid=m["player"]; self.code.delete(0,"end"); self.code.insert(0,m["code"]); self.status.set(f"Room {m['code']} - Player {self.pid+1}")
  elif t=="state":
   import time
   self.clock_offset=m.get("server_time",time.time())-time.time()
   incoming_move=m.get("last_move")
   move_key=json.dumps(incoming_move,sort_keys=True) if incoming_move else None
   if move_key and move_key != self.last_move_seen:
    self.last_move_seen=move_key; self.last_move_until=time.time()+4.0
    self.animation={"move":incoming_move,"started":time.time(),"duration":0.85}
   self.state=m; self.selected=None; self.moves.clear(); self.update_last_move(); self.update_players(); self.draw(); self.update_status()
  elif t=="legal": self.moves={tuple(x) for x in m["moves"]}; self.draw()
  elif t=="chat": self.add_chat(f"{m['name']}: {m['text']}")
  elif t=="system": self.add_chat(m["text"])
  elif t=="error": self.add_chat("ERROR: "+m.get("message","Unknown error"))


 def tick_timer(self):
  if self.state and self.state.get("started") and self.state.get("winner") is None and self.state.get("deadline"):
   import time
   remaining=max(0, self.state["deadline"]-(time.time()+self.clock_offset))
   self.timer_text.set(f"Time: {remaining:04.1f}s")
   self.timer_text.set("Time: 0.0s" if remaining <= 0 else f"Time: {remaining:04.1f}s")
  else:
   self.timer_text.set("Time: --")
  self.root.after(100,self.tick_timer)


 def update_last_move(self):
  move=self.state.get("last_move") if self.state else None
  if not move:
   self.last_move_text.set("Last move: none")
   return
  def sq(pos):
   row,col=pos; return f"{chr(65+col)}{row+1}"
  capture=f"; captured {move['capture']}" if move.get("capture") else ""
  self.last_move_text.set(f"Last move: Player {move['player']+1} {move['piece']} {sq(move['from'])} -> {sq(move['to'])}{capture}")

 def update_players(self):
  self.players.delete(0,"end")
  if not self.state:return
  bots=set(self.state.get("bots",[]))
  for key,name in sorted(self.state.get("players",{}).items(), key=lambda x:int(x[0])):
   pid=int(key); flags=[]
   if pid==self.pid:flags.append("YOU")
   if pid in bots:flags.append("AI")
   if self.state.get("started") and pid==self.state.get("turn"):flags.append("TURN")
   suffix=(" ["+", ".join(flags)+"]") if flags else ""
   self.players.insert("end",f"Player {pid+1}: {name}{suffix}")

 def update_status(self):
  if not self.state:return
  if self.state["winner"] is not None: extra=f"Winner: Player {self.state['winner']+1}"
  elif not self.state["started"]: extra="Lobby - press Start when ready"
  else: extra=f"Turn: Player {self.state['turn']+1}"
  self.status.set(f"Room {self.state['code']} | You: {self.pid+1 if self.pid is not None else '?'} | {extra}")
 def add_chat(self,text):
  self.chat.configure(state="normal"); self.chat.insert("end",text+"\n"); self.chat.see("end"); self.chat.configure(state="disabled")
 def chat_send(self,event=None):
  text=self.chat_entry.get().strip()
  if text:self.send({"type":"chat","text":text}); self.chat_entry.delete(0,"end")
 def geometry(self):
  w,h=max(1,self.canvas.winfo_width()),max(1,self.canvas.winfo_height()); size=min(w,h); cell=size/16; ox=(w-size)/2; oy=(h-size)/2
  return cell,ox,oy,size
 def click(self,e):
  if not self.state or not self.state["started"]: return
  cell,ox,oy,size=self.geometry(); col=int((e.x-ox)//cell); row=int((e.y-oy)//cell)
  if not (0<=row<16 and 0<=col<16): return
  if self.selected is not None and (row,col) in self.moves:
   self.send({"type":"move","piece":self.selected,"row":row,"col":col}); return
  p=next((p for p in self.state["pieces"] if p["alive"] and p["row"]==row and p["col"]==col),None)
  if p and p["owner"]==self.pid and self.state["turn"]==self.pid:
   self.selected=p["id"]; self.send({"type":"legal","piece":p["id"]})
  else:self.selected=None; self.moves.clear(); self.draw()
 def draw(self):
  self.canvas.delete("all")
  if not self.state:return
  cell,ox,oy,size=self.geometry()
  for r in range(16):
   for c in range(16): self.canvas.create_rectangle(ox+c*cell,oy+r*cell,ox+(c+1)*cell,oy+(r+1)*cell,fill=LIGHT if (r+c)%2==0 else DARK,outline="#242337")
  pieces=[p for p in self.state["pieces"] if p["alive"]]
  import time
  last=self.state.get("last_move")
  if last:
   fr,fc=last["from"]; tr,tc=last["to"]
   for row,col,color in ((fr,fc,"#FACC15"),(tr,tc,"#22D3EE")):
    self.canvas.create_rectangle(ox+col*cell+3,oy+row*cell+3,ox+(col+1)*cell-3,oy+(row+1)*cell-3,outline=color,width=max(3,int(cell*.11)))
   x1=ox+(fc+.5)*cell; y1=oy+(fr+.5)*cell; x2=ox+(tc+.5)*cell; y2=oy+(tr+.5)*cell
   self.canvas.create_line(x1,y1,x2,y2,fill="#FFFFFF",width=max(2,int(cell*.07)),arrow="last",arrowshape=(max(8,int(cell*.25)),max(10,int(cell*.32)),max(4,int(cell*.12))))
  for r,c in self.moves:
   target=next((p for p in pieces if p["row"]==r and p["col"]==c),None); rad=cell*(.34 if target else .16); x=ox+(c+.5)*cell;y=oy+(r+.5)*cell
   self.canvas.create_oval(x-rad,y-rad,x+rad,y+rad,outline="#EF4444" if target else "#22C55E",width=max(2,int(cell*.07)))
  moving_id=None
  progress=1.0
  if self.animation:
   elapsed=time.time()-self.animation["started"]
   progress=min(1.0,elapsed/self.animation["duration"])
   moving_id=self.animation["move"].get("piece_id")
   if progress < 1.0:self.root.after(16,self.draw)
   else:self.animation=None
  for p in pieces:
   if moving_id is not None and p["id"]==moving_id and progress < 1.0:
    continue
   self.draw_piece_sprite(p,ox+(p["col"]+.5)*cell,oy+(p["row"]+.5)*cell,cell,p["id"]==self.selected)
  if moving_id is not None and progress < 1.0:
   p=next((item for item in pieces if item["id"]==moving_id),None)
   if p:
    fr,fc=self.animation["move"]["from"]; tr,tc=self.animation["move"]["to"]
    eased=progress*progress*(3-2*progress)
    x=ox+(fc+(tc-fc)*eased+.5)*cell; y=oy+(fr+(tr-fr)*eased+.5)*cell
    self.draw_piece_sprite(p,x,y,cell,True)

 def draw_piece_sprite(self,p,x,y,cell,selected=False):
  rad=max(8,cell*.41)
  if selected:
   self.canvas.create_oval(x-rad-4,y-rad-4,x+rad+4,y+rad+4,outline="#FACC15",width=max(3,int(cell*.08)))
  self.canvas.create_oval(x-rad,y-rad,x+rad,y+rad,fill=COLORS[p["owner"]],outline="#FFFFFF",width=max(2,int(cell*.04)))
  # Always draw a high-contrast symbol. This guarantees every piece remains visible
  # after network and AI moves, even when an image file is missing or too dark.
  symbol=LETTERS[p["kind"]]
  self.canvas.create_text(x+1,y+2,text=symbol,fill="#000000",font=("Segoe UI",max(9,int(cell*.40)),"bold"))
  self.canvas.create_text(x,y,text=symbol,fill="#FFFFFF",font=("Segoe UI",max(9,int(cell*.40)),"bold"))
  # Small owner number makes all four armies unambiguous.
  self.canvas.create_text(x+rad*.58,y-rad*.58,text=str(p["owner"]+1),fill="#FFFFFF",font=("Segoe UI",max(6,int(cell*.16)),"bold"))


if __name__=="__main__":
 root=tk.Tk(); App(root); root.mainloop()
