from __future__ import annotations
import itertools
from dataclasses import dataclass

RANKS = "23456789TJQKA"
SUITS = "SHDC"
SYMBOL = {"S":"♠","H":"♥","D":"♦","C":"♣"}
HAND_NAMES = ["High Card","One Pair","Two Pair","Three of a Kind","Straight","Flush","Full House","Four of a Kind","Straight Flush"]

@dataclass(frozen=True)
class Card:
    rank: str
    suit: str
    def wire(self): return self.rank + self.suit
    @property
    def value(self): return RANKS.index(self.rank)+2

def card_from(text): return Card(text[0], text[1])
def deck52(): return [Card(r,s) for s in SUITS for r in RANKS]

def rank5(cards):
    vals=sorted((c.value for c in cards),reverse=True)
    counts={v:vals.count(v) for v in set(vals)}
    groups=sorted(((n,v) for v,n in counts.items()),reverse=True)
    flush=len({c.suit for c in cards})==1
    unique=sorted(set(vals),reverse=True)
    if 14 in unique: unique.append(1)
    straight=max((unique[i] for i in range(len(unique)-4) if unique[i]-unique[i+4]==4),default=0)
    if flush and straight:return (8,straight)
    if groups[0][0]==4:
        q=groups[0][1];return (7,q,max(v for v in vals if v!=q))
    if groups[0][0]==3 and len(groups)>1 and groups[1][0]==2:return (6,groups[0][1],groups[1][1])
    if flush:return (5,*vals)
    if straight:return (4,straight)
    if groups[0][0]==3:
        t=groups[0][1];return (3,t,*sorted((v for v in vals if v!=t),reverse=True))
    pairs=sorted((v for n,v in groups if n==2),reverse=True)
    if len(pairs)>=2:return (2,pairs[0],pairs[1],max(v for v in vals if v not in pairs[:2]))
    if pairs:
        p=pairs[0];return (1,p,*sorted((v for v in vals if v!=p),reverse=True))
    return (0,*vals)

def best7(cards): return max(rank5(combo) for combo in itertools.combinations(cards,5))
