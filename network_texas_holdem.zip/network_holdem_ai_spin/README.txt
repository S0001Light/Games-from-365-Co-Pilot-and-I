NETWORK TEXAS HOLD'EM - NO BURN CARDS

FILES
  server.py          authoritative room server
  client.py          Tkinter network client
  holdem_common.py   cards and hand evaluator

OPTIONAL JOKER BACK IMAGES
Put these beside client.py or in assets/:
  JKR1.gif
  JKR2.gif
They are only card backs. They are never inserted into the playable 52-card deck.
If the GIFs are missing, the client draws Joker 1 and Joker 2 fallback backs.
Each hidden card randomly receives back 1 or back 2.

RUN
  python server.py
  python client.py

LOCAL TEST
  Start the server once. Open 2-6 clients. Connect to 127.0.0.1 port 5051.
  One client creates a room. Others join with its room code. Click Start Hand.

FEATURES
  Room codes, 2-6 network players, chat, synchronized hidden/private cards,
  server-side shuffle/deal, random Joker backs, left-to-right shuffle motion,
  player seats outside the community-card area, fold/call/raise, and no burn cards.

This is a compact starter betting engine. It uses one action per active player on
each street. A later version can add full re-opening action, side pots, all-ins,
reconnection tokens, and tournament blind levels.

AI OPPONENT MODE
  1. Start server.py and client.py.
  2. Connect and create a room.
  3. Click Add AI one or more times.
  4. Click Start Hand.

AI players are server controlled and act automatically after about one second.
They evaluate hole-card strength and completed poker hands, then fold, call, or
raise. AI hidden cards use randomly selected JKR1 or JKR2 backs. One human can
play against one to five AI opponents without opening additional clients.

NO TURN TIMER / HUMAN JOIN / SPINNING CARDS
  - There is no player turn countdown and no forced timeout action.
  - AI decisions run automatically without a visible waiting timer.
  - Human players can join before a hand starts or after a showdown.
  - Chat is shared by all connected human players in the room.
  - Hidden cards use random JKR1 or JKR2 backs.
  - Shuffle cards move left to right and perform four visual spins per pass.
  - During each spin, card width compresses to an edge and expands again.
  - Start Hand can begin another hand after showdown.
