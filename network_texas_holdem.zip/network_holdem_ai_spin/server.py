import argparse,json,random,socketserver,string,threading
from holdem_common import deck52,card_from,best7,HAND_NAMES

rooms={}; lock=threading.RLock()
def code():
    while True:
        x=''.join(random.choice(string.ascii_uppercase+string.digits) for _ in range(6))
        if x not in rooms:return x

def send(h,m): h.request.sendall((json.dumps(m)+"\n").encode())

class Room:
    def __init__(self,c):
        self.code=c;self.players={};self.clients={};self.bots=set();self.deck=[];self.holes={};self.backs={}
        self.community=[];self.folded=set();self.chips={};self.bets={};self.pot=0;self.current_bet=0
        self.street='lobby';self.turn=None;self.dealer=-1;self.started=False;self.chat=[];self.shuffle_order=[]
    def active(self):return [p for p in sorted(self.players) if p not in self.folded and self.chips.get(p,0)>0]
    def public(self,viewer):
        showdown=self.street=='showdown'
        holes={}
        for p,cards in self.holes.items():holes[str(p)]=cards if p==viewer or showdown else [None,None]
        return {'type':'state','code':self.code,'players':self.players,'chips':self.chips,'bets':self.bets,
          'pot':self.pot,'current_bet':self.current_bet,'street':self.street,'turn':self.turn,'dealer':self.dealer,
          'community':self.community,'holes':holes,'backs':self.backs,'bots':sorted(self.bots),'folded':sorted(self.folded),'started':self.started}
    def broadcast(self,m):
        raw=(json.dumps(m)+"\n").encode();dead=[]
        for p,h in list(self.clients.items()):
            try:h.request.sendall(raw)
            except OSError:dead.append(p)
        for p in dead:self.clients.pop(p,None)
    def states(self):
        for p,h in list(self.clients.items()):
            try:send(h,self.public(p))
            except OSError:self.clients.pop(p,None)
    def next_active(self,p):
        a=self.active()
        if not a:return None
        return next((x for x in a if x>p),a[0])
    def begin_hand(self):
        if len(self.players)<2:return False
        self.deck=deck52();random.shuffle(self.deck);self.shuffle_order=[c.wire() for c in self.deck]
        self.community=[];self.folded=set();self.holes={p:[] for p in self.players};self.backs={}
        self.bets={p:0 for p in self.players};self.pot=0;self.current_bet=0;self.dealer=(self.dealer+1)%len(self.players)
        for p in self.players:
            self.chips.setdefault(p,1000);self.backs[str(p)]=[random.randint(1,2),random.randint(1,2)]
        self.street='shuffle'; self.started=True
        self.broadcast({'type':'shuffle','cards':self.shuffle_order,'backs':[random.randint(1,2) for _ in range(24)]})
        threading.Timer(3.2,self.finish_deal).start();return True
    def finish_deal(self):
        with lock:
            if self.street!='shuffle':return
            seats=sorted(self.players)
            for _ in range(2):
                for p in seats:self.holes[p].append(self.deck.pop().wire())
            sb=seats[(self.dealer+1)%len(seats)];bb=seats[(self.dealer+2)%len(seats)]
            self.pay(sb,25);self.pay(bb,50);self.current_bet=50;self.street='preflop';self.turn=seats[(self.dealer+3)%len(seats)]
            self.states();self.schedule_bot()
    def pay(self,p,amount):
        n=min(amount,self.chips[p]);self.chips[p]-=n;self.bets[p]+=n;self.pot+=n
    def next_street(self):
        self.bets={p:0 for p in self.players};self.current_bet=0
        if self.street=='preflop':self.community += [self.deck.pop().wire() for _ in range(3)];self.street='flop'
        elif self.street=='flop':self.community.append(self.deck.pop().wire());self.street='turn'
        elif self.street=='turn':self.community.append(self.deck.pop().wire());self.street='river'
        elif self.street=='river':return self.showdown()
        self.turn=self.next_active(self.dealer);self.states();self.schedule_bot()
    def showdown(self):
        active=self.active(); ranked={p:best7([card_from(x) for x in self.holes[p]+self.community]) for p in active}
        high=max(ranked.values());wins=[p for p,v in ranked.items() if v==high];share=self.pot//len(wins)
        for p in wins:self.chips[p]+=share
        self.street='showdown';self.turn=None;self.started=False;self.broadcast({'type':'notice','text':f"Showdown: {', '.join(self.players[p] for p in wins)} win with {HAND_NAMES[high[0]]}."});self.pot=0;self.states()

    def schedule_bot(self):
        if self.turn in self.bots and self.street not in ('lobby','shuffle','showdown'):
            threading.Timer(0.05,self.bot_action,args=(self.turn,)).start()
    def bot_strength(self,p):
        cards=[card_from(x) for x in self.holes.get(p,[])+self.community]
        if len(cards)>=5:
            rank=best7(cards);return rank[0]*20+max(c.value for c in cards)
        hole=cards[:2]
        if len(hole)<2:return 0
        pair=hole[0].rank==hole[1].rank;suited=hole[0].suit==hole[1].suit
        return sum(c.value for c in hole)+(18 if pair else 0)+(4 if suited else 0)
    def bot_action(self,p):
        with lock:
            if self.turn!=p or p not in self.bots or p in self.folded:return
            need=max(0,self.current_bet-self.bets[p]);strength=self.bot_strength(p)
            if need and strength<19 and random.random()<0.55:
                action='fold'
            elif strength>34 and self.chips[p]>need+50 and random.random()<0.30:
                action='raise'
            else:action='call'
            self.apply_action(p,action)
    def apply_action(self,p,a):
        if self.turn!=p or p in self.folded:return
        if a=='fold':self.folded.add(p)
        elif a=='call':self.pay(p,max(0,self.current_bet-self.bets[p]))
        elif a=='raise':
            self.pay(p,max(0,self.current_bet-self.bets[p])+50);self.current_bet=self.bets[p]
        active=self.active()
        if len(active)==1:
            w=active[0];self.chips[w]+=self.pot;self.broadcast({'type':'notice','text':f'{self.players[w]} wins; all others folded.'});self.pot=0;self.street='showdown';self.turn=None;self.started=False;self.states();return
        nxt=self.next_active(p)
        start=self.next_active(self.dealer)
        if nxt is None or nxt==start:self.next_street()
        else:
            self.turn=nxt;self.states();self.schedule_bot()

class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        self.room=None;self.pid=None
        while True:
            line=self.rfile.readline()
            if not line:break
            try:
                with lock:self.process(json.loads(line))
            except Exception as e:
                try:send(self,{'type':'error','message':str(e)})
                except:break
    def process(self,m):
        t=m.get('type')
        if t=='create':
            r=Room(code());rooms[r.code]=r;return self.join(r,m.get('name','Player'))
        if t=='join':
            r=rooms.get(str(m.get('code','')).upper())
            if not r:return send(self,{'type':'error','message':'Room not found.'})
            if r.started and r.street not in ('lobby','showdown'):
                return send(self,{'type':'error','message':'A hand is running. Join after the showdown.'})
            return self.join(r,m.get('name','Player'))
        if not self.room:return send(self,{'type':'error','message':'Join a room first.'})
        r=self.room
        if t=='add_bot':
            if r.started and r.street not in ('lobby','showdown'):
                return send(self,{'type':'error','message':'Add AI before a hand or after showdown.'})
            p=next((x for x in range(6) if x not in r.players),None)
            if p is None:return send(self,{'type':'error','message':'Room full.'})
            r.players[p]=f'AI Player {p+1}';r.bots.add(p);r.chips[p]=1000;r.states()
        elif t=='start':
            if not r.begin_hand():send(self,{'type':'error','message':'Add at least one AI opponent first.'})
        elif t=='action':self.action(m.get('action'))
        elif t=='chat':
            text=str(m.get('text','')).strip()[:250]
            if text:r.broadcast({'type':'chat','name':r.players[self.pid],'text':text})
    def join(self,r,name):
        p=next((x for x in range(6) if x not in r.players),None)
        if p is None:return send(self,{'type':'error','message':'Room full.'})
        self.room=r;self.pid=p;r.players[p]=str(name)[:20] or 'Player';r.clients[p]=self;r.chips[p]=1000
        send(self,{'type':'joined','code':r.code,'player':p});r.states()
    def action(self,a):
        self.room.apply_action(self.pid,a)
    def finish(self):
        with lock:
            if self.room and self.pid is not None:self.room.clients.pop(self.pid,None)

class Server(socketserver.ThreadingTCPServer):allow_reuse_address=True;daemon_threads=True
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--host',default='0.0.0.0');ap.add_argument('--port',type=int,default=5051);a=ap.parse_args()
    with Server((a.host,a.port),Handler) as s:print(f'Holdem server on {a.host}:{a.port}');s.serve_forever()
