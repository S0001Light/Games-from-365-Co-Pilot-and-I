import json,math,queue,socket,threading,time,tkinter as tk
from pathlib import Path
from tkinter import messagebox
from holdem_common import SYMBOL

BG='#07111f';FELT='#075c3b';PANEL='#0d1b2e';WHITE='#f8fafc';GOLD='#facc15';RED='#ef4444';CYAN='#22d3ee'
class App:
 def __init__(self,root):
  self.root=root;root.title("Network Texas Hold'em - No Burn Cards");root.geometry('1250x850');root.minsize(900,650);root.configure(bg=BG);root.rowconfigure(1,weight=1);root.columnconfigure(0,weight=1)
  self.sock=None;self.q=queue.Queue();self.pid=None;self.state=None;self.anim=None;self.images={};self.load_backs()
  top=tk.Frame(root,bg=PANEL,padx=8,pady=7);top.grid(row=0,column=0,sticky='ew');top.columnconfigure(11,weight=1)
  self.host=tk.Entry(top,width=14);self.host.insert(0,'127.0.0.1');self.host.grid(row=0,column=0,padx=2)
  self.port=tk.Entry(top,width=6);self.port.insert(0,'5051');self.port.grid(row=0,column=1,padx=2)
  self.name=tk.Entry(top,width=12);self.name.insert(0,'Player');self.name.grid(row=0,column=2,padx=2)
  tk.Button(top,text='Connect',command=self.connect).grid(row=0,column=3,padx=2)
  tk.Button(top,text='Create Room',command=lambda:self.send({'type':'create','name':self.name.get()})).grid(row=0,column=4,padx=2)
  self.code=tk.Entry(top,width=8);self.code.grid(row=0,column=5,padx=2)
  tk.Button(top,text='Join',command=lambda:self.send({'type':'join','code':self.code.get(),'name':self.name.get()})).grid(row=0,column=6,padx=2)
  tk.Button(top,text='Add AI',command=lambda:self.send({'type':'add_bot'})).grid(row=0,column=7,padx=2)
  tk.Button(top,text='Start Hand',command=lambda:self.send({'type':'start'})).grid(row=0,column=8,padx=2)
  self.status=tk.StringVar(value='Connect to server');tk.Label(top,textvariable=self.status,bg=PANEL,fg=WHITE).grid(row=0,column=11,sticky='e')
  pane=tk.PanedWindow(root,orient='horizontal',sashwidth=6,bg=BG);pane.grid(row=1,column=0,sticky='nsew',padx=8,pady=8)
  frame=tk.Frame(pane,bg=BG);frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1);self.c=tk.Canvas(frame,bg=FELT,highlightthickness=0);self.c.grid(sticky='nsew');self.c.bind('<Configure>',lambda e:self.draw());pane.add(frame,stretch='always')
  side=tk.Frame(pane,bg=PANEL,width=280,padx=8,pady=8);side.rowconfigure(2,weight=1);side.columnconfigure(0,weight=1);pane.add(side,minsize=240,width=280)
  tk.Label(side,text='PLAYERS / CHAT',bg=PANEL,fg=GOLD,font=('Segoe UI',11,'bold')).grid(row=0,column=0,sticky='w',pady=(0,5))
  self.players=tk.Listbox(side,height=8,bg=BG,fg=WHITE);self.players.grid(row=1,column=0,sticky='ew')
  self.chat=tk.Text(side,state='disabled',bg=BG,fg=WHITE,wrap='word');self.chat.grid(row=2,column=0,sticky='nsew',pady=8)
  self.entry=tk.Entry(side);self.entry.grid(row=3,column=0,sticky='ew');self.entry.bind('<Return>',self.chat_send)
  controls=tk.Frame(root,bg=PANEL,padx=8,pady=8);controls.grid(row=2,column=0,sticky='ew');self.buttons=[]
  for text,act in [('Fold','fold'),('Check / Call','call'),('Raise 50','raise')]:
   b=tk.Button(controls,text=text,command=lambda x=act:self.send({'type':'action','action':x}),state='disabled',width=12);b.pack(side='left',padx=4);self.buttons.append(b)
  root.after(40,self.poll);root.after(16,self.animate)
 def load_backs(self):
  base=Path(__file__).parent
  for n in (1,2):
   for p in (base/f'JKR{n}.gif',base/'assets'/f'JKR{n}.gif'):
    if p.exists():
     try:self.images[n]=tk.PhotoImage(file=str(p));break
     except tk.TclError:pass
 def connect(self):
  try:
   self.sock=socket.create_connection((self.host.get().strip(),int(self.port.get())),timeout=5)
   self.sock.settimeout(None)
   threading.Thread(target=self.read,daemon=True).start()
   self.status.set('Connected - no idle timeout')
  except Exception as e:messagebox.showerror('Connect',str(e))
 def read(self):
  try:
   for line in self.sock.makefile('r',encoding='utf8'):self.q.put(json.loads(line))
  except socket.timeout:
   self.q.put({'type':'error','message':'Connection read timeout was ignored; reconnect with this fixed client.'})
  except Exception as e:self.q.put({'type':'error','message':str(e)})
 def send(self,m):
  if not self.sock:return
  self.sock.sendall((json.dumps(m)+'\n').encode())
 def poll(self):
  while True:
   try:self.handle(self.q.get_nowait())
   except queue.Empty:break
  self.root.after(40,self.poll)
 def handle(self,m):
  t=m.get('type')
  if t=='joined':self.pid=m['player'];self.code.delete(0,'end');self.code.insert(0,m['code'])
  elif t=='state':self.state=m;self.refresh();self.draw()
  elif t=='shuffle':self.anim={'start':time.time(),'cards':m['cards'],'backs':m['backs']};self.draw()
  elif t=='chat':self.log(f"{m['name']}: {m['text']}")
  elif t=='notice':self.log(m['text'])
  elif t=='error':self.log('ERROR: '+m['message'])
 def refresh(self):
  s=self.state
  if not s:return
  self.status.set(f"Room {s['code']} | {s['street']} | Pot {s['pot']} | No turn timer")
  self.players.delete(0,'end')
  for k,name in sorted(s['players'].items(),key=lambda x:int(x[0])):
   p=int(k);flags=[]
   if p==self.pid:flags.append('YOU')
   if p==s['dealer']:flags.append('D')
   if p in s.get('bots',[]):flags.append('AI')
   if p==s['turn']:flags.append('TURN')
   if p in s['folded']:flags.append('FOLD')
   self.players.insert('end',f"{name}: {s['chips'].get(k,s['chips'].get(p,0))} {' '.join(flags)}")
  enabled=s['turn']==self.pid
  for b in self.buttons:b.config(state='normal' if enabled else 'disabled')
 def log(self,text):
  self.chat.config(state='normal');self.chat.insert('end',text+'\n');self.chat.see('end');self.chat.config(state='disabled')
 def chat_send(self,e=None):
  text=self.entry.get().strip()
  if text:self.send({'type':'chat','text':text});self.entry.delete(0,'end')
 def card(self,x,y,wire=None,hidden=False,back=1,scale=1,spin=1.0):
  # spin ranges from near 0 to 1 and compresses card width, creating a
  # horizontal card-flip/spin effect while the card travels left to right.
  full_w,full_h=58*scale,82*scale
  w=max(3,full_w*abs(spin));h=full_h
  self.c.create_rectangle(x-w/2,y-h/2,x+w/2,y+h/2,fill='white' if not hidden else '#172554',outline=GOLD,width=max(1,int(2*scale)))
  if abs(spin)<0.20:
   self.c.create_line(x,y-h/2,x,y+h/2,fill=CYAN,width=max(2,int(3*scale)))
   return
  if hidden:
   img=self.images.get(back)
   # PhotoImage cannot be continuously scaled to arbitrary widths in Tk, so
   # use it near face-on and use the fallback Joker art during the edge phase.
   if img and abs(spin)>0.82:self.c.create_image(x,y,image=img)
   else:
    self.c.create_text(x,y-8,text='JOKER',fill=CYAN if back==1 else RED,font=('Segoe UI',max(6,int(9*scale*abs(spin))),'bold'))
    self.c.create_text(x,y+10,text=str(back),fill=WHITE,font=('Segoe UI',max(8,int(17*scale*abs(spin))),'bold'))
  elif wire:
   rank,suit=wire[0],wire[1];color=RED if suit in 'HD' else '#111827';self.c.create_text(x,y,text=('10' if rank=='T' else rank)+SYMBOL[suit],fill=color,font=('Consolas',max(7,int(16*scale*abs(spin))),'bold'))

 def animate(self):
  if self.anim:
   elapsed=time.time()-self.anim['start']
   if elapsed>3.0:self.anim=None
   self.draw()
  self.root.after(16,self.animate)
 def draw(self):
  c=self.c;c.delete('all');w=max(1,c.winfo_width());h=max(1,c.winfo_height());c.create_oval(w*.08,h*.08,w*.92,h*.92,fill=FELT,outline='#d6a848',width=7)
  if self.anim:
   t=(time.time()-self.anim['start'])/3.0
   c.create_text(w/2,h*.15,text='SHUFFLE: JOKER BACKS MOVING LEFT TO RIGHT',fill=WHITE,font=('Segoe UI',15,'bold'))
   for i in range(24):
    lane=i%6
    phase=(t*1.8+i/24)%1.0
    x=-50+phase*(w+100)
    y=h*.25+lane*h*.09
    # Four complete visual spins during each left-to-right pass.
    spin=math.cos((phase*4.0+i*.17)*math.tau)
    self.card(x,y,hidden=True,back=self.anim['backs'][i],scale=.72,spin=spin)
   return
  if not self.state:return
  s=self.state;seats=sorted((int(k),v) for k,v in s['players'].items());pos=[(.5,.80),(.18,.63),(.18,.30),(.5,.17),(.82,.30),(.82,.63)]
  for p,name in seats:
   x,y=w*pos[p][0],h*pos[p][1];c.create_text(x,y-58,text=name,fill=RED if p in s['folded'] else WHITE,font=('Segoe UI',10,'bold'))
   cards=s['holes'].get(str(p),[None,None]);backs=s['backs'].get(str(p),[1,2])
   for i,card in enumerate(cards):self.card(x+(i-.5)*66,y,card,hidden=card is None,back=backs[i])
  c.create_text(w/2,h*.40,text=f"POT {s['pot']}  |  {s['street'].upper()}",fill=GOLD,font=('Consolas',15,'bold'))
  for i in range(5):self.card(w/2+(i-2)*68,h*.52,s['community'][i] if i<len(s['community']) else None,hidden=i>=len(s['community']),back=1+(i%2))
  c.create_text(w/2,h*.95,text='52-card deck • Joker images are card backs only • No burn cards',fill='#d1fae5',font=('Segoe UI',9))
if __name__=='__main__':root=tk.Tk();App(root);root.mainloop()
