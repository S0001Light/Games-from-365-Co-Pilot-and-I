"""
Expandable Custom-Image Slot Machine
-------------------------------------

Features:
- Starts with 10,000 fake credits
- Loads numbered custom images from the images folder
- Supports PNG, JPG, JPEG, BMP and non-animated GIF
- Accepts uppercase or lowercase filename extensions
- Custom images must be numbered:
      1.png
      2.jpg
      3.bmp
      4.gif
- Scans the folder instead of guessing filenames
- Shows exactly which images loaded in the terminal
- Uses generated numbered symbols only when no images load
- Configurable 3, 4 or 5 reels
- Configurable rows
- Left-side paytable displays payouts for 3, 4 and 5 matches
- Paytable updates automatically when the bet changes
- Multiple paylines
- Sound effects with automatic WAV generation
- Resizable Pygame window
- Fake-credit reset
"""

import math
import os
import random
import struct
import sys
import wave

import pygame


# ============================================================
# CONFIGURATION
# ============================================================

TITLE = "Custom Image Slot Machine"

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 800
FPS = 60

STARTING_CREDITS = 10_000

# Change this to 3, 4 or 5.
REEL_COUNT = 5

VISIBLE_ROWS = 3

# Ignore image numbers higher than this.
MAX_TILE_NUMBER = 100

# Used only when no custom images load.
MINIMUM_SYMBOL_COUNT = 8

IMAGE_FOLDER = "images"
SOUND_FOLDER = "sounds"

SUPPORTED_IMAGE_EXTENSIONS = (
    ".png",
    ".jpg",
    ".jpeg",
    ".bmp",
    ".gif",
)

MIN_BET_PER_LINE = 1
MAX_BET_PER_LINE = 1_000
BET_STEP = 5
DEFAULT_BET_PER_LINE = 10

MAX_ACTIVE_LINES = 20

BASE_SPIN_DURATION = 1_150
REEL_STOP_DELAY = 320
RESULT_DISPLAY_TIME = 3_000

SPIN_STEP_MIN = 45
SPIN_STEP_MAX = 85

REEL_GAP = 10
ROW_GAP = 10
TILE_CORNER_RADIUS = 14

# Window layout.
PAYTABLE_AREA = pygame.Rect(20, 155, 250, 445)
REEL_AREA = pygame.Rect(290, 155, 965, 445)
STATUS_AREA = pygame.Rect(20, 620, 1235, 48)

# Colors.
BACKGROUND = (16, 18, 34)
PANEL = (29, 34, 58)
PANEL_LIGHT = (42, 49, 80)
REEL_BACKGROUND = (7, 10, 22)

GOLD = (255, 205, 60)
GOLD_DARK = (177, 124, 24)

WHITE = (245, 247, 255)
LIGHT_TEXT = (190, 199, 226)

GREEN = (54, 220, 130)
RED = (245, 75, 93)
BLUE = (64, 145, 255)
PURPLE = (167, 99, 255)
ORANGE = (255, 135, 45)
BLACK = (0, 0, 0)

# Base multiplier for each numbered symbol.
#
# Actual line payout:
#
# bet_per_line
#     x symbol multiplier
#     x match-count multiplier
PAYOUT_MULTIPLIERS = {
    1: 100,
    2: 75,
    3: 50,
    4: 40,
    5: 30,
    6: 25,
    7: 20,
    8: 15,
    9: 12,
    10: 10,
}

DEFAULT_SYMBOL_MULTIPLIER = 5

# Multipliers for matching 3, 4 or 5 symbols.
MATCH_COUNT_MULTIPLIERS = {
    3: 1,
    4: 3,
    5: 10,
}

MINIMUM_MATCH_COUNT = 3


# ============================================================
# PATHS
# ============================================================

def get_program_directory():
    """Return the directory containing the program."""

    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)

    return os.path.dirname(os.path.abspath(__file__))


BASE_DIRECTORY = get_program_directory()
IMAGE_PATH = os.path.join(BASE_DIRECTORY, IMAGE_FOLDER)
SOUND_PATH = os.path.join(BASE_DIRECTORY, SOUND_FOLDER)


# ============================================================
# AUDIO
# ============================================================

def generate_tone_wav(
    filename,
    frequencies,
    duration=0.20,
    volume=0.35,
    sample_rate=44_100,
):
    """Generate a simple WAV sound effect."""

    if isinstance(frequencies, (int, float)):
        frequencies = [frequencies]

    os.makedirs(os.path.dirname(filename), exist_ok=True)

    frame_count = max(1, int(duration * sample_rate))
    frames = bytearray()

    for sample_index in range(frame_count):
        current_time = sample_index / sample_rate
        progress = sample_index / frame_count

        # Fade the tone toward the end.
        envelope = max(0.0, 1.0 - progress)

        sample_value = 0.0

        for frequency in frequencies:
            sample_value += math.sin(
                2.0 * math.pi * frequency * current_time
            )

        sample_value /= max(1, len(frequencies))
        sample_value *= envelope
        sample_value *= volume

        sample_value = max(-1.0, min(1.0, sample_value))
        signed_sample = int(sample_value * 32_767)

        frames.extend(struct.pack("<h", signed_sample))

    with wave.open(filename, "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(frames)


def create_default_sounds():
    """Generate missing sound-effect files."""

    os.makedirs(SOUND_PATH, exist_ok=True)

    sound_definitions = {
        "spin.wav": ([110, 165], 0.42, 0.22),
        "reel_stop.wav": ([240, 360], 0.10, 0.32),
        "win.wav": ([523, 659, 784], 0.72, 0.32),
        "jackpot.wav": ([523, 659, 784, 1047], 1.35, 0.34),
        "button.wav": ([440], 0.07, 0.24),
    }

    for filename, settings in sound_definitions.items():
        full_path = os.path.join(SOUND_PATH, filename)

        if os.path.isfile(full_path):
            continue

        frequencies, duration, volume = settings

        try:
            generate_tone_wav(
                full_path,
                frequencies,
                duration,
                volume,
            )
        except OSError as error:
            print("Could not generate sound:", full_path)
            print("Reason:", error)


class SoundManager:
    """Safely load and play slot-machine effects."""

    def __init__(self):
        self.enabled = pygame.mixer.get_init() is not None
        self.muted = False
        self.sounds = {}

        if not self.enabled:
            print("Sound is unavailable.")
            return

        sound_files = {
            "spin": "spin.wav",
            "stop": "reel_stop.wav",
            "win": "win.wav",
            "jackpot": "jackpot.wav",
            "button": "button.wav",
        }

        for sound_name, filename in sound_files.items():
            full_path = os.path.join(SOUND_PATH, filename)

            try:
                sound = pygame.mixer.Sound(full_path)
                sound.set_volume(0.65)
                self.sounds[sound_name] = sound
            except (pygame.error, OSError) as error:
                self.sounds[sound_name] = None
                print("Could not load sound:", full_path)
                print("Reason:", error)

    def play(self, sound_name):
        if not self.enabled or self.muted:
            return

        sound = self.sounds.get(sound_name)

        if sound is not None:
            try:
                sound.play()
            except pygame.error:
                pass

    def toggle_mute(self):
        self.muted = not self.muted
        return self.muted


# ============================================================
# SYMBOLS AND IMAGE LOADING
# ============================================================

class SlotSymbol:
    """One numbered slot-machine symbol."""

    def __init__(self, number, image, original_filename=None):
        self.number = number
        self.image = image
        self.original_filename = original_filename

    @property
    def payout_multiplier(self):
        return PAYOUT_MULTIPLIERS.get(
            self.number,
            DEFAULT_SYMBOL_MULTIPLIER,
        )


def create_numbered_tile(number, width, height):
    """Create a generated numbered symbol."""

    surface = pygame.Surface(
        (width, height),
        pygame.SRCALPHA,
    )

    color_seed = (number * 47) % 255

    main_color = (
        55 + color_seed % 140,
        45 + (color_seed * 2) % 130,
        70 + (color_seed * 3) % 150,
    )

    border_color = (
        min(255, main_color[0] + 45),
        min(255, main_color[1] + 45),
        min(255, main_color[2] + 45),
    )

    pygame.draw.rect(
        surface,
        main_color,
        surface.get_rect(),
        border_radius=TILE_CORNER_RADIUS,
    )

    inner_rectangle = surface.get_rect().inflate(-12, -12)

    pygame.draw.rect(
        surface,
        border_color,
        inner_rectangle,
        width=4,
        border_radius=max(2, TILE_CORNER_RADIUS - 4),
    )

    font_size = max(28, min(width, height) // 2)
    number_font = pygame.font.Font(None, font_size)

    shadow = number_font.render(str(number), True, BLACK)
    number_text = number_font.render(str(number), True, WHITE)

    text_rectangle = number_text.get_rect(
        center=surface.get_rect().center
    )

    surface.blit(shadow, text_rectangle.move(4, 5))
    surface.blit(number_text, text_rectangle)

    multiplier = PAYOUT_MULTIPLIERS.get(
        number,
        DEFAULT_SYMBOL_MULTIPLIER,
    )

    caption_font = pygame.font.Font(
        None,
        max(18, font_size // 4),
    )

    caption = caption_font.render(
        f"{multiplier}x",
        True,
        GOLD,
    )

    caption_rectangle = caption.get_rect(
        centerx=surface.get_rect().centerx,
        bottom=surface.get_rect().bottom - 12,
    )

    surface.blit(caption, caption_rectangle)

    return surface


def fit_image_to_tile(source_image, width, height):
    """Scale an image without stretching its proportions."""

    tile = pygame.Surface(
        (width, height),
        pygame.SRCALPHA,
    )

    tile.fill((18, 20, 32, 255))

    source_width = source_image.get_width()
    source_height = source_image.get_height()

    if source_width <= 0 or source_height <= 0:
        return tile

    padding = 8

    available_width = max(1, width - padding * 2)
    available_height = max(1, height - padding * 2)

    scale_amount = min(
        available_width / source_width,
        available_height / source_height,
    )

    destination_width = max(
        1,
        int(source_width * scale_amount),
    )

    destination_height = max(
        1,
        int(source_height * scale_amount),
    )

    scaled_image = pygame.transform.smoothscale(
        source_image,
        (destination_width, destination_height),
    )

    destination_rectangle = scaled_image.get_rect(
        center=tile.get_rect().center
    )

    tile.blit(scaled_image, destination_rectangle)

    pygame.draw.rect(
        tile,
        (225, 230, 255),
        tile.get_rect(),
        width=3,
        border_radius=TILE_CORNER_RADIUS,
    )

    return tile


def get_custom_image_files():
    """
    Scan the images directory for numbered image files.

    Accepted examples:
        1.png
        2.JPG
        3.bmp
        4.GIF
        005.png
    """

    os.makedirs(IMAGE_PATH, exist_ok=True)

    print()
    print("========================================")
    print("CUSTOM SLOT IMAGE LOADER")
    print("========================================")
    print("Program folder:", BASE_DIRECTORY)
    print("Image folder  :", IMAGE_PATH)
    print(
        "Extended image support:",
        pygame.image.get_extended(),
    )
    print()

    try:
        directory_files = os.listdir(IMAGE_PATH)
    except OSError as error:
        print("Could not read the images folder.")
        print("Reason:", error)
        return []

    found_images = []

    for filename in directory_files:
        full_path = os.path.join(IMAGE_PATH, filename)

        if not os.path.isfile(full_path):
            continue

        base_name, extension = os.path.splitext(filename)
        extension = extension.lower()

        if extension not in SUPPORTED_IMAGE_EXTENSIONS:
            print("IGNORED unsupported file:", filename)
            continue

        if not base_name.isdigit():
            print("IGNORED non-numbered image:", filename)
            continue

        number = int(base_name)

        if number < 1:
            print("IGNORED invalid image number:", filename)
            continue

        if number > MAX_TILE_NUMBER:
            print(
                "IGNORED image over MAX_TILE_NUMBER:",
                filename,
            )
            continue

        found_images.append(
            (number, filename, full_path)
        )

    found_images.sort(key=lambda item: item[0])

    return found_images


def load_symbols(tile_width, tile_height):
    """
    Load numbered custom images.

    Generated symbols are used only when no custom images load.
    """

    image_files = get_custom_image_files()

    symbols = []
    loaded_numbers = set()

    for number, filename, full_path in image_files:
        if number in loaded_numbers:
            print("IGNORED duplicate number:", filename)
            continue

        try:
            print("Trying:", full_path)

            raw_image = pygame.image.load(full_path)

            if raw_image.get_alpha() is not None:
                raw_image = raw_image.convert_alpha()
            else:
                raw_image = raw_image.convert()

            fitted_image = fit_image_to_tile(
                raw_image,
                tile_width,
                tile_height,
            )

            symbols.append(
                SlotSymbol(
                    number,
                    fitted_image,
                    filename,
                )
            )

            loaded_numbers.add(number)

            print(
                "LOADED:",
                filename,
                raw_image.get_width(),
                "x",
                raw_image.get_height(),
            )

        except (pygame.error, OSError) as error:
            print()
            print("FAILED TO LOAD:", filename)
            print("Full path:", full_path)
            print("Reason:", error)
            print()

    if symbols:
        symbols.sort(key=lambda symbol: symbol.number)

        print()
        print("----------------------------------------")
        print("CUSTOM IMAGES SUCCESSFULLY LOADED")
        print("----------------------------------------")

        for symbol in symbols:
            print(
                "Symbol",
                symbol.number,
                "=",
                symbol.original_filename,
            )

        print("Total custom symbols:", len(symbols))
        print("----------------------------------------")
        print()

        return symbols

    print()
    print("****************************************")
    print("NO CUSTOM IMAGES COULD BE LOADED")
    print("****************************************")
    print("Expected folder:")
    print(IMAGE_PATH)
    print()
    print("Expected numbered files such as:")
    print("1.png")
    print("2.jpg")
    print("3.bmp")
    print("4.gif")
    print()
    print("Creating generated numbered symbols.")
    print()

    for number in range(1, MINIMUM_SYMBOL_COUNT + 1):
        generated_image = create_numbered_tile(
            number,
            tile_width,
            tile_height,
        )

        symbols.append(
            SlotSymbol(
                number,
                generated_image,
                None,
            )
        )

    return symbols


# ============================================================
# PAYLINES
# ============================================================

def build_paylines(reel_count, row_count):
    """Create paylines for the selected reel and row count."""

    paylines = []

    # Straight horizontal lines.
    for row in range(row_count):
        paylines.append([row] * reel_count)

    if row_count >= 3:
        middle = row_count // 2
        top = 0
        bottom = row_count - 1

        paylines.append(
            [
                abs((index % (2 * middle)) - middle)
                for index in range(reel_count)
            ]
        )

        paylines.append(
            [
                bottom
                - abs((index % (2 * middle)) - middle)
                for index in range(reel_count)
            ]
        )

        paylines.append(
            [
                top if index % 2 == 0 else middle
                for index in range(reel_count)
            ]
        )

        paylines.append(
            [
                bottom if index % 2 == 0 else middle
                for index in range(reel_count)
            ]
        )

        paylines.append(
            [
                middle if index % 2 == 0 else top
                for index in range(reel_count)
            ]
        )

        paylines.append(
            [
                middle if index % 2 == 0 else bottom
                for index in range(reel_count)
            ]
        )

        paylines.append(
            [
                top if index % 2 == 0 else bottom
                for index in range(reel_count)
            ]
        )

        paylines.append(
            [
                bottom if index % 2 == 0 else top
                for index in range(reel_count)
            ]
        )

    # Additional diagonal patterns.
    for offset in range(row_count):
        diagonal_down = [
            (index + offset) % row_count
            for index in range(reel_count)
        ]

        diagonal_up = [
            (offset - index) % row_count
            for index in range(reel_count)
        ]

        paylines.append(diagonal_down)
        paylines.append(diagonal_up)

    # Remove duplicates.
    unique_paylines = []
    existing_lines = set()

    for payline in paylines:
        payline_key = tuple(payline)

        if payline_key in existing_lines:
            continue

        existing_lines.add(payline_key)
        unique_paylines.append(payline)

    return unique_paylines[:MAX_ACTIVE_LINES]


# ============================================================
# BUTTON
# ============================================================

class Button:
    def __init__(
        self,
        rectangle,
        text,
        normal_color,
        hover_color,
        disabled_color=(70, 72, 85),
    ):
        self.rect = pygame.Rect(rectangle)
        self.text = text
        self.normal_color = normal_color
        self.hover_color = hover_color
        self.disabled_color = disabled_color
        self.enabled = True

    def draw(self, surface, font):
        mouse_position = pygame.mouse.get_pos()

        if not self.enabled:
            color = self.disabled_color
        elif self.rect.collidepoint(mouse_position):
            color = self.hover_color
        else:
            color = self.normal_color

        pygame.draw.rect(
            surface,
            color,
            self.rect,
            border_radius=12,
        )

        pygame.draw.rect(
            surface,
            WHITE if self.enabled else LIGHT_TEXT,
            self.rect,
            width=2,
            border_radius=12,
        )

        rendered_text = font.render(
            self.text,
            True,
            WHITE if self.enabled else LIGHT_TEXT,
        )

        surface.blit(
            rendered_text,
            rendered_text.get_rect(
                center=self.rect.center
            ),
        )

    def clicked(self, event):
        return (
            self.enabled
            and event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
            and self.rect.collidepoint(event.pos)
        )


# ============================================================
# REEL
# ============================================================

class Reel:
    def __init__(
        self,
        reel_index,
        symbols,
        visible_rows,
    ):
        self.reel_index = reel_index
        self.symbols = symbols
        self.visible_rows = visible_rows

        self.result_indexes = [
            random.randrange(len(symbols))
            for _ in range(visible_rows)
        ]

        self.display_indexes = list(self.result_indexes)

        self.spinning = False
        self.stop_time = 0
        self.last_step_time = 0
        self.step_interval = SPIN_STEP_MIN

    def begin_spin(self, current_time, stop_time):
        self.spinning = True
        self.stop_time = stop_time
        self.last_step_time = current_time

        self.step_interval = random.randint(
            SPIN_STEP_MIN,
            SPIN_STEP_MAX,
        )

        self.result_indexes = [
            random.randrange(len(self.symbols))
            for _ in range(self.visible_rows)
        ]

    def update(self, current_time):
        """
        Update reel animation.

        Returns True once when the reel stops.
        """

        if not self.spinning:
            return False

        if current_time >= self.stop_time:
            self.spinning = False
            self.display_indexes = list(self.result_indexes)
            return True

        if (
            current_time - self.last_step_time
            >= self.step_interval
        ):
            self.last_step_time = current_time

            self.display_indexes = [
                random.randrange(len(self.symbols))
                for _ in range(self.visible_rows)
            ]

        return False

    def get_symbol(self, row):
        return self.symbols[self.display_indexes[row]]

    def get_result_symbol(self, row):
        return self.symbols[self.result_indexes[row]]


# ============================================================
# SLOT MACHINE
# ============================================================

class SlotMachine:
    def __init__(self):
        pygame.display.set_caption(TITLE)

        self.screen = pygame.display.set_mode(
            (SCREEN_WIDTH, SCREEN_HEIGHT),
            pygame.RESIZABLE,
        )

        self.canvas = pygame.Surface(
            (SCREEN_WIDTH, SCREEN_HEIGHT)
        )

        self.clock = pygame.time.Clock()

        self.title_font = pygame.font.Font(None, 52)
        self.large_font = pygame.font.Font(None, 42)
        self.medium_font = pygame.font.Font(None, 29)
        self.small_font = pygame.font.Font(None, 22)
        self.tiny_font = pygame.font.Font(None, 18)

        create_default_sounds()
        self.sound_manager = SoundManager()

        self.credits = STARTING_CREDITS
        self.bet_per_line = DEFAULT_BET_PER_LINE

        self.paylines = build_paylines(
            REEL_COUNT,
            VISIBLE_ROWS,
        )

        self.active_lines = min(
            max(1, VISIBLE_ROWS),
            len(self.paylines),
        )

        self.spinning = False
        self.last_win = 0
        self.last_winning_lines = []

        self.message = "Press SPIN or Space"
        self.message_color = LIGHT_TEXT
        self.result_message_end = 0

        self.paytable_scroll = 0

        reel_width, row_height = self.calculate_reel_layout()

        self.source_tile_width = max(120, reel_width - 8)
        self.source_tile_height = max(90, row_height - 8)

        self.symbols = load_symbols(
            self.source_tile_width,
            self.source_tile_height,
        )

        self.reels = [
            Reel(
                reel_index,
                self.symbols,
                VISIBLE_ROWS,
            )
            for reel_index in range(REEL_COUNT)
        ]

        self.create_buttons()

    def create_buttons(self):
        button_y = 690
        button_height = 58

        self.bet_down_button = Button(
            (25, button_y, 115, button_height),
            "BET -",
            (60, 93, 175),
            (80, 125, 225),
        )

        self.bet_up_button = Button(
            (150, button_y, 115, button_height),
            "BET +",
            (60, 93, 175),
            (80, 125, 225),
        )

        self.lines_down_button = Button(
            (285, button_y, 125, button_height),
            "LINES -",
            (88, 67, 165),
            (125, 88, 220),
        )

        self.lines_up_button = Button(
            (420, button_y, 125, button_height),
            "LINES +",
            (88, 67, 165),
            (125, 88, 220),
        )

        self.max_bet_button = Button(
            (565, button_y, 135, button_height),
            "MAX BET",
            (168, 100, 23),
            (223, 143, 30),
        )

        self.sound_button = Button(
            (715, button_y, 115, button_height),
            "SOUND",
            (50, 115, 112),
            (58, 166, 156),
        )

        self.spin_button = Button(
            (850, button_y - 6, 400, button_height + 12),
            "SPIN",
            (31, 158, 86),
            (45, 215, 118),
        )

    @property
    def total_bet(self):
        return self.bet_per_line * self.active_lines

    def can_spin(self):
        return (
            not self.spinning
            and self.total_bet > 0
            and self.credits >= self.total_bet
        )

    def calculate_reel_layout(self):
        available_width = (
            REEL_AREA.width
            - (REEL_COUNT - 1) * REEL_GAP
        )

        reel_width = available_width // REEL_COUNT

        available_height = (
            REEL_AREA.height
            - (VISIBLE_ROWS - 1) * ROW_GAP
        )

        row_height = available_height // VISIBLE_ROWS

        return reel_width, row_height

    def update_button_states(self):
        controls_enabled = not self.spinning

        self.bet_down_button.enabled = (
            controls_enabled
            and self.bet_per_line > MIN_BET_PER_LINE
        )

        self.bet_up_button.enabled = (
            controls_enabled
            and self.bet_per_line < MAX_BET_PER_LINE
        )

        self.lines_down_button.enabled = (
            controls_enabled
            and self.active_lines > 1
        )

        self.lines_up_button.enabled = (
            controls_enabled
            and self.active_lines < len(self.paylines)
        )

        self.max_bet_button.enabled = controls_enabled
        self.sound_button.enabled = True
        self.spin_button.enabled = self.can_spin()

    def start_spin(self):
        if self.spinning:
            return

        if self.credits < self.total_bet:
            self.message = "Not enough fake credits"
            self.message_color = RED
            self.sound_manager.play("button")
            return

        self.credits -= self.total_bet

        self.last_win = 0
        self.last_winning_lines = []

        self.spinning = True
        self.message = "Spinning..."
        self.message_color = GOLD

        current_time = pygame.time.get_ticks()

        for reel_index, reel in enumerate(self.reels):
            stop_time = (
                current_time
                + BASE_SPIN_DURATION
                + reel_index * REEL_STOP_DELAY
            )

            reel.begin_spin(
                current_time,
                stop_time,
            )

        self.sound_manager.play("spin")

    def get_match_multiplier(self, match_count):
        if match_count in MATCH_COUNT_MULTIPLIERS:
            return MATCH_COUNT_MULTIPLIERS[match_count]

        highest_configured_match = max(
            MATCH_COUNT_MULTIPLIERS
        )

        return MATCH_COUNT_MULTIPLIERS[
            highest_configured_match
        ]

    def evaluate_spin(self):
        total_win = 0
        winning_lines = []

        for line_number in range(self.active_lines):
            payline = self.paylines[line_number]

            line_symbols = [
                self.reels[reel_index].get_result_symbol(
                    payline[reel_index]
                )
                for reel_index in range(REEL_COUNT)
            ]

            first_number = line_symbols[0].number
            match_count = 1

            for symbol in line_symbols[1:]:
                if symbol.number == first_number:
                    match_count += 1
                else:
                    break

            if match_count < MINIMUM_MATCH_COUNT:
                continue

            symbol_multiplier = PAYOUT_MULTIPLIERS.get(
                first_number,
                DEFAULT_SYMBOL_MULTIPLIER,
            )

            match_multiplier = self.get_match_multiplier(
                match_count
            )

            line_win = (
                self.bet_per_line
                * symbol_multiplier
                * match_multiplier
            )

            total_win += line_win

            winning_lines.append(
                {
                    "line_index": line_number,
                    "symbol_number": first_number,
                    "match_count": match_count,
                    "amount": line_win,
                    "rows": payline,
                }
            )

        self.last_win = total_win
        self.last_winning_lines = winning_lines

        if total_win > 0:
            self.credits += total_win

            full_reel_win = any(
                result["match_count"] == REEL_COUNT
                for result in winning_lines
            )

            if full_reel_win:
                self.message = (
                    f"JACKPOT! WON {total_win:,} CREDITS"
                )
                self.sound_manager.play("jackpot")
            else:
                self.message = (
                    f"WIN! {total_win:,} CREDITS"
                )
                self.sound_manager.play("win")

            self.message_color = GREEN
        else:
            self.message = "No win. Try another spin."
            self.message_color = LIGHT_TEXT

        self.result_message_end = (
            pygame.time.get_ticks()
            + RESULT_DISPLAY_TIME
        )

    def change_bet(self, amount):
        if self.spinning:
            return

        self.bet_per_line = max(
            MIN_BET_PER_LINE,
            min(
                MAX_BET_PER_LINE,
                self.bet_per_line + amount,
            ),
        )

        self.sound_manager.play("button")

    def change_lines(self, amount):
        if self.spinning:
            return

        self.active_lines = max(
            1,
            min(
                len(self.paylines),
                self.active_lines + amount,
            ),
        )

        self.sound_manager.play("button")

    def set_max_bet(self):
        if self.spinning:
            return

        self.active_lines = len(self.paylines)

        affordable_per_line = (
            self.credits // self.active_lines
        )

        if affordable_per_line <= 0:
            self.bet_per_line = MIN_BET_PER_LINE
        else:
            self.bet_per_line = min(
                MAX_BET_PER_LINE,
                max(
                    MIN_BET_PER_LINE,
                    affordable_per_line,
                ),
            )

        self.sound_manager.play("button")

    def reset_credits(self):
        if self.spinning:
            return

        self.credits = STARTING_CREDITS
        self.last_win = 0
        self.last_winning_lines = []

        self.message = "Fake credits reset to 10,000"
        self.message_color = GOLD

        self.sound_manager.play("button")

    def scroll_paytable(self, amount):
        visible_rows = 8

        maximum_scroll = max(
            0,
            len(self.symbols) - visible_rows,
        )

        self.paytable_scroll = max(
            0,
            min(
                maximum_scroll,
                self.paytable_scroll + amount,
            ),
        )

    def screen_to_canvas_position(self, position):
        window_width, window_height = self.screen.get_size()

        if window_width <= 0 or window_height <= 0:
            return position

        canvas_x = (
            position[0]
            * SCREEN_WIDTH
            / window_width
        )

        canvas_y = (
            position[1]
            * SCREEN_HEIGHT
            / window_height
        )

        return int(canvas_x), int(canvas_y)

    def handle_event(self, event):
        if event.type == pygame.QUIT:
            return False

        if event.type == pygame.KEYDOWN:
            if event.key in (
                pygame.K_SPACE,
                pygame.K_RETURN,
            ):
                self.start_spin()

            elif event.key in (
                pygame.K_UP,
                pygame.K_EQUALS,
                pygame.K_PLUS,
            ):
                self.change_bet(BET_STEP)

            elif event.key in (
                pygame.K_DOWN,
                pygame.K_MINUS,
            ):
                self.change_bet(-BET_STEP)

            elif event.key == pygame.K_RIGHT:
                self.change_lines(1)

            elif event.key == pygame.K_LEFT:
                self.change_lines(-1)

            elif event.key == pygame.K_PAGEUP:
                self.scroll_paytable(-1)

            elif event.key == pygame.K_PAGEDOWN:
                self.scroll_paytable(1)

            elif event.key == pygame.K_m:
                muted = self.sound_manager.toggle_mute()
                self.sound_button.text = (
                    "MUTED" if muted else "SOUND"
                )

            elif event.key == pygame.K_r:
                self.reset_credits()

            elif event.key == pygame.K_ESCAPE:
                return False

        if event.type == pygame.MOUSEWHEEL:
            mouse_canvas_position = (
                self.screen_to_canvas_position(
                    pygame.mouse.get_pos()
                )
            )

            if PAYTABLE_AREA.collidepoint(
                mouse_canvas_position
            ):
                self.scroll_paytable(-event.y)

        if event.type == pygame.MOUSEBUTTONDOWN:
            translated_event = pygame.event.Event(
                event.type,
                {
                    "button": event.button,
                    "pos": self.screen_to_canvas_position(
                        event.pos
                    ),
                },
            )
        else:
            translated_event = event

        if self.spin_button.clicked(translated_event):
            self.start_spin()

        elif self.bet_down_button.clicked(translated_event):
            self.change_bet(-BET_STEP)

        elif self.bet_up_button.clicked(translated_event):
            self.change_bet(BET_STEP)

        elif self.lines_down_button.clicked(translated_event):
            self.change_lines(-1)

        elif self.lines_up_button.clicked(translated_event):
            self.change_lines(1)

        elif self.max_bet_button.clicked(translated_event):
            self.set_max_bet()

        elif self.sound_button.clicked(translated_event):
            muted = self.sound_manager.toggle_mute()

            self.sound_button.text = (
                "MUTED" if muted else "SOUND"
            )

            if not muted:
                self.sound_manager.play("button")

        return True

    def update(self):
        current_time = pygame.time.get_ticks()
        reel_stopped_this_frame = False

        if self.spinning:
            all_reels_stopped = True

            for reel in self.reels:
                reel_just_stopped = reel.update(
                    current_time
                )

                if reel_just_stopped:
                    reel_stopped_this_frame = True

                if reel.spinning:
                    all_reels_stopped = False

            if reel_stopped_this_frame:
                self.sound_manager.play("stop")

            if all_reels_stopped:
                self.spinning = False
                self.evaluate_spin()

        elif (
            self.result_message_end > 0
            and current_time >= self.result_message_end
        ):
            self.result_message_end = 0

            if self.credits < self.total_bet:
                self.message = (
                    "Lower the bet or press R to reset"
                )
                self.message_color = RED
            else:
                self.message = "Press SPIN or Space"
                self.message_color = LIGHT_TEXT

        self.update_button_states()

    def draw_header(self):
        title = self.title_font.render(
            "CUSTOM IMAGE SLOT MACHINE",
            True,
            GOLD,
        )

        self.canvas.blit(
            title,
            title.get_rect(
                center=(SCREEN_WIDTH // 2, 34)
            ),
        )

        credits_text = self.large_font.render(
            f"CREDITS: {self.credits:,}",
            True,
            WHITE,
        )

        bet_text = self.medium_font.render(
            f"Bet/line: {self.bet_per_line:,}",
            True,
            LIGHT_TEXT,
        )

        lines_text = self.medium_font.render(
            f"Lines: {self.active_lines}/"
            f"{len(self.paylines)}",
            True,
            LIGHT_TEXT,
        )

        total_bet_text = self.medium_font.render(
            f"Total bet: {self.total_bet:,}",
            True,
            GOLD,
        )

        self.canvas.blit(credits_text, (35, 75))
        self.canvas.blit(bet_text, (435, 83))
        self.canvas.blit(lines_text, (665, 83))
        self.canvas.blit(total_bet_text, (930, 83))

        message_surface = self.medium_font.render(
            self.message,
            True,
            self.message_color,
        )

        self.canvas.blit(
            message_surface,
            message_surface.get_rect(
                center=(SCREEN_WIDTH // 2, 127)
            ),
        )

    def get_available_match_counts(self):
        """
        Return 3/4/5 payout columns when possible.

        Three reels show 3.
        Four reels show 3 and 4.
        Five reels show 3, 4 and 5.
        """

        return list(
            range(
                MINIMUM_MATCH_COUNT,
                REEL_COUNT + 1,
            )
        )

    def draw_paytable(self):
        """Draw the current-bet payout table."""

        pygame.draw.rect(
            self.canvas,
            PANEL,
            PAYTABLE_AREA,
            border_radius=18,
        )

        pygame.draw.rect(
            self.canvas,
            GOLD_DARK,
            PAYTABLE_AREA,
            width=3,
            border_radius=18,
        )

        title = self.medium_font.render(
            "PAYS BY BET",
            True,
            GOLD,
        )

        self.canvas.blit(
            title,
            title.get_rect(
                centerx=PAYTABLE_AREA.centerx,
                y=PAYTABLE_AREA.y + 12,
            ),
        )

        bet_caption = self.tiny_font.render(
            f"Current bet per line: {self.bet_per_line:,}",
            True,
            LIGHT_TEXT,
        )

        self.canvas.blit(
            bet_caption,
            bet_caption.get_rect(
                centerx=PAYTABLE_AREA.centerx,
                y=PAYTABLE_AREA.y + 42,
            ),
        )

        match_counts = self.get_available_match_counts()

        # Dynamically locate columns for 3, 4 and 5.
        symbol_column_x = PAYTABLE_AREA.x + 15
        payout_start_x = PAYTABLE_AREA.x + 89
        payout_width = 50

        heading_y = PAYTABLE_AREA.y + 73

        symbol_heading = self.tiny_font.render(
            "SYMBOL",
            True,
            LIGHT_TEXT,
        )

        self.canvas.blit(
            symbol_heading,
            (symbol_column_x, heading_y),
        )

        for column_index, match_count in enumerate(
            match_counts
        ):
            x_position = (
                payout_start_x
                + column_index * payout_width
            )

            heading = self.tiny_font.render(
                str(match_count),
                True,
                GOLD,
            )

            self.canvas.blit(
                heading,
                heading.get_rect(
                    centerx=x_position + 20,
                    y=heading_y,
                ),
            )

        separator_y = heading_y + 23

        pygame.draw.line(
            self.canvas,
            GOLD_DARK,
            (
                PAYTABLE_AREA.x + 10,
                separator_y,
            ),
            (
                PAYTABLE_AREA.right - 10,
                separator_y,
            ),
            2,
        )

        row_height = 39
        first_row_y = separator_y + 8
        visible_rows = 8

        visible_symbols = self.symbols[
            self.paytable_scroll:
            self.paytable_scroll + visible_rows
        ]

        for row_index, symbol in enumerate(
            visible_symbols
        ):
            row_y = first_row_y + row_index * row_height

            if row_index % 2 == 0:
                row_rectangle = pygame.Rect(
                    PAYTABLE_AREA.x + 7,
                    row_y - 2,
                    PAYTABLE_AREA.width - 14,
                    row_height - 3,
                )

                pygame.draw.rect(
                    self.canvas,
                    PANEL_LIGHT,
                    row_rectangle,
                    border_radius=6,
                )

            preview_size = 31

            preview_image = pygame.transform.smoothscale(
                symbol.image,
                (preview_size, preview_size),
            )

            preview_rectangle = preview_image.get_rect(
                x=symbol_column_x,
                centery=row_y + 16,
            )

            self.canvas.blit(
                preview_image,
                preview_rectangle,
            )

            symbol_number = self.tiny_font.render(
                f"#{symbol.number}",
                True,
                WHITE,
            )

            self.canvas.blit(
                symbol_number,
                (
                    symbol_column_x + 36,
                    row_y + 9,
                ),
            )

            symbol_multiplier = (
                PAYOUT_MULTIPLIERS.get(
                    symbol.number,
                    DEFAULT_SYMBOL_MULTIPLIER,
                )
            )

            for column_index, match_count in enumerate(
                match_counts
            ):
                match_multiplier = (
                    self.get_match_multiplier(
                        match_count
                    )
                )

                payout = (
                    self.bet_per_line
                    * symbol_multiplier
                    * match_multiplier
                )

                payout_text = self.tiny_font.render(
                    f"{payout:,}",
                    True,
                    GREEN
                    if match_count == REEL_COUNT
                    else WHITE,
                )

                x_position = (
                    payout_start_x
                    + column_index * payout_width
                )

                self.canvas.blit(
                    payout_text,
                    payout_text.get_rect(
                        centerx=x_position + 20,
                        y=row_y + 9,
                    ),
                )

        if len(self.symbols) > visible_rows:
            scroll_message = self.tiny_font.render(
                "Mouse wheel or PgUp/PgDn",
                True,
                LIGHT_TEXT,
            )

            self.canvas.blit(
                scroll_message,
                scroll_message.get_rect(
                    centerx=PAYTABLE_AREA.centerx,
                    bottom=PAYTABLE_AREA.bottom - 7,
                ),
            )

    def draw_reels(self):
        outer_rectangle = REEL_AREA.inflate(16, 16)

        pygame.draw.rect(
            self.canvas,
            PANEL,
            outer_rectangle,
            border_radius=22,
        )

        pygame.draw.rect(
            self.canvas,
            GOLD_DARK,
            outer_rectangle,
            width=4,
            border_radius=22,
        )

        reel_width, row_height = (
            self.calculate_reel_layout()
        )

        for reel_index, reel in enumerate(self.reels):
            reel_x = (
                REEL_AREA.x
                + reel_index
                * (reel_width + REEL_GAP)
            )

            reel_rectangle = pygame.Rect(
                reel_x,
                REEL_AREA.y,
                reel_width,
                REEL_AREA.height,
            )

            pygame.draw.rect(
                self.canvas,
                REEL_BACKGROUND,
                reel_rectangle,
                border_radius=13,
            )

            for row_index in range(VISIBLE_ROWS):
                tile_y = (
                    REEL_AREA.y
                    + row_index
                    * (row_height + ROW_GAP)
                )

                tile_rectangle = pygame.Rect(
                    reel_x,
                    tile_y,
                    reel_width,
                    row_height,
                )

                symbol = reel.get_symbol(row_index)

                scaled_symbol = pygame.transform.smoothscale(
                    symbol.image,
                    (
                        max(1, reel_width - 8),
                        max(1, row_height - 8),
                    ),
                )

                symbol_rectangle = scaled_symbol.get_rect(
                    center=tile_rectangle.center
                )

                self.canvas.blit(
                    scaled_symbol,
                    symbol_rectangle,
                )

                number_label = self.tiny_font.render(
                    f"#{symbol.number}",
                    True,
                    WHITE,
                )

                label_rectangle = number_label.get_rect(
                    topleft=(
                        tile_rectangle.x + 8,
                        tile_rectangle.y + 7,
                    )
                ).inflate(8, 4)

                pygame.draw.rect(
                    self.canvas,
                    BLACK,
                    label_rectangle,
                    border_radius=5,
                )

                self.canvas.blit(
                    number_label,
                    number_label.get_rect(
                        center=label_rectangle.center
                    ),
                )

        self.draw_winning_lines(
            reel_width,
            row_height,
        )

    def get_payline_color(self, index):
        colors = [
            GOLD,
            GREEN,
            BLUE,
            PURPLE,
            RED,
            ORANGE,
            (65, 230, 220),
            (255, 90, 185),
        ]

        return colors[index % len(colors)]

    def draw_winning_lines(
        self,
        reel_width,
        row_height,
    ):
        if not self.last_winning_lines:
            return

        if self.spinning:
            return

        for win_index, winning_line in enumerate(
            self.last_winning_lines
        ):
            payline = winning_line["rows"]
            match_count = winning_line["match_count"]

            points = []

            for reel_index in range(match_count):
                reel_x = (
                    REEL_AREA.x
                    + reel_index
                    * (reel_width + REEL_GAP)
                )

                row_index = payline[reel_index]

                tile_y = (
                    REEL_AREA.y
                    + row_index
                    * (row_height + ROW_GAP)
                )

                points.append(
                    (
                        reel_x + reel_width // 2,
                        tile_y + row_height // 2,
                    )
                )

            if len(points) < 2:
                continue

            line_color = self.get_payline_color(
                win_index
            )

            pygame.draw.lines(
                self.canvas,
                BLACK,
                False,
                points,
                10,
            )

            pygame.draw.lines(
                self.canvas,
                line_color,
                False,
                points,
                5,
            )

            for point in points:
                pygame.draw.circle(
                    self.canvas,
                    line_color,
                    point,
                    8,
                )

    def draw_status_panel(self):
        pygame.draw.rect(
            self.canvas,
            PANEL_LIGHT,
            STATUS_AREA,
            border_radius=12,
        )

        status_text = (
            f"Loaded symbols: {len(self.symbols)}   "
            f"Reels: {REEL_COUNT}   "
            f"Rows: {VISIBLE_ROWS}"
        )

        if self.last_win > 0:
            status_text += (
                f"   Last win: {self.last_win:,}"
            )

        rendered_status = self.small_font.render(
            status_text,
            True,
            WHITE,
        )

        self.canvas.blit(
            rendered_status,
            rendered_status.get_rect(
                center=STATUS_AREA.center
            ),
        )

    def draw_buttons(self):
        buttons = [
            self.bet_down_button,
            self.bet_up_button,
            self.lines_down_button,
            self.lines_up_button,
            self.max_bet_button,
            self.sound_button,
            self.spin_button,
        ]

        for button in buttons:
            button.draw(
                self.canvas,
                self.small_font,
            )

        help_text = self.tiny_font.render(
            "Space: spin   Up/Down: bet   "
            "Left/Right: lines   M: sound   "
            "R: reset credits   Esc: quit",
            True,
            LIGHT_TEXT,
        )

        self.canvas.blit(
            help_text,
            help_text.get_rect(
                center=(SCREEN_WIDTH // 2, 777)
            ),
        )

    def draw(self):
        self.canvas.fill(BACKGROUND)

        self.draw_header()
        self.draw_paytable()
        self.draw_reels()
        self.draw_status_panel()
        self.draw_buttons()

        window_width, window_height = (
            self.screen.get_size()
        )

        if (
            window_width == SCREEN_WIDTH
            and window_height == SCREEN_HEIGHT
        ):
            self.screen.blit(self.canvas, (0, 0))
        else:
            scaled_canvas = pygame.transform.smoothscale(
                self.canvas,
                (window_width, window_height),
            )

            self.screen.blit(scaled_canvas, (0, 0))

        pygame.display.flip()

    def run(self):
        running = True

        while running:
            for event in pygame.event.get():
                running = self.handle_event(event)

                if not running:
                    break

            self.update()
            self.draw()
            self.clock.tick(FPS)

        pygame.quit()


# ============================================================
# STARTUP
# ============================================================

def initialize_pygame():
    """Initialize video, fonts and sound."""

    pygame.mixer.pre_init(
        frequency=44_100,
        size=-16,
        channels=2,
        buffer=512,
    )

    pygame.init()

    if pygame.mixer.get_init() is None:
        try:
            pygame.mixer.init(
                frequency=44_100,
                size=-16,
                channels=2,
                buffer=512,
            )
        except pygame.error as error:
            print("Audio is unavailable:", error)
            print(
                "The slot machine will continue "
                "without sound."
            )


def main():
    initialize_pygame()

    try:
        machine = SlotMachine()
        machine.run()

    except pygame.error as error:
        pygame.quit()
        print("Pygame error:", error)
        raise


if __name__ == "__main__":
    main()
